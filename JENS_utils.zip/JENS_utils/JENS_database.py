#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MySQL数据库操作模块
负责系统与MySQL数据库的交互
包含连接池管理和基本的数据库操作
"""

import os
import time
import pymysql
from pymysql.cursors import DictCursor
from dbutils.pooled_db import PooledDB
import logging

from .JENS_config import Config

class JENSDatabase:
    """MySQL数据库操作类"""
    _instance = None
    _pool = None
    
    def __new__(cls, *args, **kwargs):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super(JENSDatabase, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """初始化数据库连接池"""
        if self._pool is None:
            config = Config().get_db_config()
            try:
                self._pool = PooledDB(
                    creator=pymysql,
                    maxconnections=6,  # 连接池最大连接数
                    mincached=2,       # 初始化时连接池中至少创建的空闲连接
                    maxcached=5,       # 连接池中最多闲置的连接
                    maxshared=3,       # 共享连接数
                    blocking=True,     # 连接池中如果没有可用连接后是否阻塞
                    maxusage=None,     # 一个连接最多被重复使用的次数
                    setsession=[],     # 开始会话前执行的命令
                    ping=0,            # 是否在每次请求时ping服务端
                    host=config.get('host', 'localhost'),
                    port=config.get('port', 3306),
                    user=config.get('user', 'root'),
                    password=config.get('password', 'root'),
                    database=config.get('database', 'jens_fire_smoke'),
                    charset=config.get('charset', 'utf8mb4'),
                )
                self._init_tables()
                logging.info("数据库连接池初始化成功")
            except Exception as e:
                logging.error(f"数据库连接池初始化失败: {str(e)}")
                raise e
    
    def _init_tables(self):
        """初始化数据库表结构"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 创建设备表
            create_device_table = """
            CREATE TABLE IF NOT EXISTS `jens_devices` (
              `id` INT NOT NULL AUTO_INCREMENT,
              `device_name` VARCHAR(100) NOT NULL COMMENT '设备名称',
              `device_type` VARCHAR(50) NOT NULL COMMENT '设备类型',
              `ip_address` VARCHAR(50) NULL COMMENT 'IP地址',
              `port` INT NULL COMMENT '端口号',
              `username` VARCHAR(50) NULL COMMENT '用户名',
              `password` VARCHAR(100) NULL COMMENT '密码',
              `status` TINYINT NOT NULL DEFAULT 0 COMMENT '设备状态：0-离线，1-在线',
              `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
              `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              UNIQUE INDEX `device_name_UNIQUE` (`device_name` ASC)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备信息表';
            """
            
            # 创建报警事件表
            create_alarm_table = """
            CREATE TABLE IF NOT EXISTS `jens_alarms` (
              `id` INT NOT NULL AUTO_INCREMENT,
              `device_id` INT NOT NULL COMMENT '设备ID',
              `alarm_type` TINYINT NOT NULL COMMENT '报警类型：1-火焰，2-烟雾',
              `confidence` FLOAT NOT NULL COMMENT '置信度',
              `alarm_level` TINYINT NOT NULL COMMENT '报警级别：1-低，2-中，3-高',
              `image_path` VARCHAR(255) NULL COMMENT '报警图片路径',
              `video_path` VARCHAR(255) NULL COMMENT '报警视频路径',
              `processed` TINYINT NOT NULL DEFAULT 0 COMMENT '是否处理：0-未处理，1-已处理',
              `process_note` VARCHAR(500) NULL COMMENT '处理备注',
              `process_time` DATETIME NULL COMMENT '处理时间',
              `process_user` VARCHAR(50) NULL COMMENT '处理人',
              `alarm_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报警时间',
              PRIMARY KEY (`id`),
              INDEX `idx_device_id` (`device_id` ASC),
              INDEX `idx_alarm_time` (`alarm_time` ASC)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报警事件表';
            """
            
            # 创建用户表
            create_user_table = """
            CREATE TABLE IF NOT EXISTS `jens_users` (
              `id` INT NOT NULL AUTO_INCREMENT,
              `username` VARCHAR(50) NOT NULL COMMENT '用户名',
              `password` VARCHAR(100) NOT NULL COMMENT '密码',
              `real_name` VARCHAR(50) NULL COMMENT '真实姓名',
              `email` VARCHAR(100) NULL COMMENT '邮箱',
              `phone` VARCHAR(20) NULL COMMENT '电话',
              `role` TINYINT NOT NULL DEFAULT 2 COMMENT '角色：1-管理员，2-普通用户',
              `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
              `last_login` DATETIME NULL COMMENT '最后登录时间',
              `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
              `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              UNIQUE INDEX `username_UNIQUE` (`username` ASC)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
            """
            
            # 创建系统配置表
            create_config_table = """
            CREATE TABLE IF NOT EXISTS `jens_configs` (
              `id` INT NOT NULL AUTO_INCREMENT,
              `config_key` VARCHAR(50) NOT NULL COMMENT '配置键',
              `config_value` VARCHAR(500) NOT NULL COMMENT '配置值',
              `description` VARCHAR(200) NULL COMMENT '配置描述',
              `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              UNIQUE INDEX `config_key_UNIQUE` (`config_key` ASC)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';
            """
            
            # 执行创建表SQL
            cursor.execute(create_device_table)
            cursor.execute(create_alarm_table)
            cursor.execute(create_user_table)
            cursor.execute(create_config_table)
            
            # 检查是否需要创建默认管理员账户
            cursor.execute("SELECT COUNT(*) FROM jens_users WHERE role = 1")
            if cursor.fetchone()[0] == 0:
                # 创建默认管理员账户 (用户名: admin, 密码: admin123)
                # 注意：实际应用中应该对密码进行加密存储
                cursor.execute(
                    "INSERT INTO jens_users (username, password, real_name, role) VALUES (%s, %s, %s, %s)",
                    ('admin', 'admin123', '系统管理员', 1)
                )
            
            conn.commit()
    
    def get_connection(self):
        """获取数据库连接"""
        return self._pool.connection()
    
    def execute_query(self, sql, params=None):
        """执行查询操作，返回查询结果"""
        with self.get_connection() as conn:
            cursor = conn.cursor(DictCursor)
            cursor.execute(sql, params)
            return cursor.fetchall()
    
    def execute_scalar(self, sql, params=None):
        """执行查询操作，返回单个值"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            result = cursor.fetchone()
            return result[0] if result else None
    
    def execute_non_query(self, sql, params=None):
        """执行非查询操作，返回影响行数"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            affected_rows = cursor.execute(sql, params)
            conn.commit()
            return affected_rows
    
    def insert(self, table, data):
        """插入数据
        Args:
            table: 表名
            data: 字典形式的数据 {'字段1': '值1', '字段2': '值2'}
        Returns:
            插入记录的ID
        """
        fields = ', '.join(data.keys())
        placeholders = ', '.join(['%s'] * len(data))
        sql = f"INSERT INTO {table} ({fields}) VALUES ({placeholders})"
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, list(data.values()))
            conn.commit()
            return cursor.lastrowid
    
    def update(self, table, data, condition):
        """更新数据
        Args:
            table: 表名
            data: 要更新的数据 {'字段1': '新值1', '字段2': '新值2'}
            condition: 更新条件 {'字段1': '值1', '字段2': '值2'}
        Returns:
            影响的行数
        """
        set_clause = ', '.join([f"{k} = %s" for k in data.keys()])
        where_clause = ' AND '.join([f"{k} = %s" for k in condition.keys()])
        sql = f"UPDATE {table} SET {set_clause} WHERE {where_clause}"
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, list(data.values()) + list(condition.values()))
            conn.commit()
            return cursor.rowcount
    
    def delete(self, table, condition):
        """删除数据
        Args:
            table: 表名
            condition: 删除条件 {'字段1': '值1', '字段2': '值2'}
        Returns:
            影响的行数
        """
        where_clause = ' AND '.join([f"{k} = %s" for k in condition.keys()])
        sql = f"DELETE FROM {table} WHERE {where_clause}"
        
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, list(condition.values()))
            conn.commit()
            return cursor.rowcount
    
    def add_alarm_event(self, device_id, alarm_type, confidence, alarm_level, image_path=None, video_path=None):
        """添加报警事件
        Args:
            device_id: 设备ID
            alarm_type: 报警类型 1-火焰 2-烟雾
            confidence: 置信度
            alarm_level: 报警级别 1-低 2-中 3-高
            image_path: 报警图片路径
            video_path: 报警视频路径
        Returns:
            插入记录的ID
        """
        data = {
            'device_id': device_id,
            'alarm_type': alarm_type,
            'confidence': confidence,
            'alarm_level': alarm_level,
            'image_path': image_path,
            'video_path': video_path
        }
        return self.insert('jens_alarms', data)
    
    def get_recent_alarms(self, limit=50, offset=0):
        """获取最近的报警事件
        Args:
            limit: 返回记录数量限制
            offset: 记录偏移量
        Returns:
            报警事件列表
        """
        sql = """
        SELECT a.*, d.device_name
        FROM jens_alarms a
        JOIN jens_devices d ON a.device_id = d.id
        ORDER BY a.alarm_time DESC
        LIMIT %s OFFSET %s
        """
        return self.execute_query(sql, (limit, offset))
    
    def get_alarm_stats(self, days=7):
        """获取最近n天的报警统计
        Args:
            days: 天数
        Returns:
            按日期和报警类型统计的报警数量
        """
        sql = """
        SELECT 
            DATE(alarm_time) as date,
            alarm_type,
            COUNT(*) as count
        FROM jens_alarms
        WHERE alarm_time >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
        GROUP BY DATE(alarm_time), alarm_type
        ORDER BY date ASC, alarm_type ASC
        """
        return self.execute_query(sql, (days,))
    
    def add_device(self, device_name, device_type, ip_address=None, port=None, username=None, password=None):
        """添加设备
        Args:
            device_name: 设备名称
            device_type: 设备类型
            ip_address: IP地址
            port: 端口号
            username: 用户名
            password: 密码
        Returns:
            插入记录的ID
        """
        data = {
            'device_name': device_name,
            'device_type': device_type,
            'ip_address': ip_address,
            'port': port,
            'username': username,
            'password': password
        }
        return self.insert('jens_devices', data)
    
    def get_all_devices(self):
        """获取所有设备"""
        sql = "SELECT * FROM jens_devices ORDER BY id ASC"
        return self.execute_query(sql) 