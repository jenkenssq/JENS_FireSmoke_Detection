#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
日志记录模块
负责系统日志的记录和管理
"""

import os
import logging
from logging.handlers import RotatingFileHandler
import datetime
from pathlib import Path

from .JENS_config import Config

class JENSLogger:
    """日志管理类"""
    _instance = None
    _initialized = False
    
    def __new__(cls, *args, **kwargs):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super(JENSLogger, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """初始化日志系统"""
        if not self._initialized:
            self._setup_logger()
            self._initialized = True
    
    def _get_log_dir(self):
        """获取日志目录"""
        # 获取应用根目录
        app_dir = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        log_dir = app_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir
    
    def _setup_logger(self):
        """设置日志系统"""
        config = Config().get_config("app")
        log_level_str = config.get("log_level", "INFO")
        log_level = getattr(logging, log_level_str.upper(), logging.INFO)
        
        # 获取日志文件路径
        log_dir = self._get_log_dir()
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        log_file = log_dir / f"JENS_Fire_Smoke_{today}.log"
        
        # 创建日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
        )
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(log_level)
        
        # 文件处理器（自动轮转）
        file_handler = RotatingFileHandler(
            filename=log_file,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=10,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(log_level)
        
        # 获取根日志记录器并添加处理器
        root_logger = logging.getLogger()
        root_logger.setLevel(log_level)
        
        # 清除已存在的处理器
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        # 添加处理器
        root_logger.addHandler(console_handler)
        root_logger.addHandler(file_handler)
        
        logging.info("日志系统初始化完成")
    
    def get_logger(self, name):
        """获取指定名称的日志记录器
        Args:
            name: 日志记录器名称
        Returns:
            Logger实例
        """
        return logging.getLogger(name)
    
    def set_level(self, level):
        """设置日志级别
        Args:
            level: 日志级别（DEBUG, INFO, WARNING, ERROR, CRITICAL）
        """
        log_level = getattr(logging, level.upper(), logging.INFO)
        root_logger = logging.getLogger()
        root_logger.setLevel(log_level)
        
        # 更新所有处理器的级别
        for handler in root_logger.handlers:
            handler.setLevel(log_level)
        
        # 更新配置
        Config().set_config("app", "log_level", level.upper())
        logging.info(f"日志级别已更改为: {level.upper()}")

# 初始化日志系统（在导入模块时自动执行）
logger_manager = JENSLogger()

def get_logger(name):
    """获取指定名称的日志记录器（简便方法）
    Args:
        name: 日志记录器名称
    Returns:
        Logger实例
    """
    return logger_manager.get_logger(name)
