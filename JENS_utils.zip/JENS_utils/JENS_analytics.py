#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
JENS火灾烟雾报警系统数据分析模块
负责处理历史数据分析、统计和报表生成
"""

import os
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')  # 非交互式后端，适合服务器环境
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import MaxNLocator
import seaborn as sns

from JENS_utils.JENS_config import Config
from JENS_utils.JENS_logger import get_logger
from JENS_utils.JENS_database import JENSDatabase

logger = get_logger("JENS_analytics")

class DataAnalytics:
    """数据分析类"""
    
    def __init__(self):
        """初始化数据分析器"""
        self.config = Config()
        self.db = JENSDatabase()
        
        # 分析配置
        self.analytics_config = self.config.get_config('analytics')
        
        # 报表存储目录
        self.report_dir = Path("JENS_data/reports")
        self.report_dir.mkdir(parents=True, exist_ok=True)
        
        # 图表样式配置
        self.setup_plot_style()
        
        logger.info("数据分析器初始化完成")
    
    def setup_plot_style(self):
        """设置绘图样式"""
        # 设置Seaborn样式
        sns.set(style="darkgrid")
        sns.set_context("paper")
        
        # 设置字体，支持中文
        plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans', 'Arial']
        plt.rcParams['axes.unicode_minus'] = False
    
    def get_alarm_stats(self, start_date: Optional[datetime] = None, 
                      end_date: Optional[datetime] = None) -> Dict:
        """
        获取报警统计信息
        
        参数:
            start_date: 开始日期，默认为过去30天
            end_date: 结束日期，默认为当前日期
            
        返回:
            Dict: 报警统计信息字典
        """
        # 默认查询最近30天的数据
        if not end_date:
            end_date = datetime.now()
        if not start_date:
            start_date = end_date - timedelta(days=30)
        
        try:
            # 查询报警记录
            sql = """
            SELECT 
                alarm_type,
                alarm_level,
                DATE(alarm_time) as alarm_date,
                COUNT(*) as count,
                AVG(confidence) as avg_confidence,
                MAX(confidence) as max_confidence
            FROM 
                jens_alarms
            WHERE 
                alarm_time BETWEEN %s AND %s
            GROUP BY 
                alarm_type, alarm_level, alarm_date
            ORDER BY 
                alarm_date, alarm_type, alarm_level
            """
            alarm_stats_data = self.db.execute_query(sql, (start_date, end_date))
            
            if not alarm_stats_data:
                return {
                    'total_alarms': 0,
                    'alarm_types': {'fire': 0, 'smoke': 0},
                    'alarm_levels': {'low': 0, 'medium': 0, 'high': 0},
                    'daily_stats': [],
                    'start_date': start_date.strftime('%Y-%m-%d'),
                    'end_date': end_date.strftime('%Y-%m-%d')
                }
            
            # 转换为DataFrame以便分析
            df = pd.DataFrame(alarm_stats_data)
            
            # 基本统计信息
            total_alarms = df['count'].sum()
            
            # 按类型统计
            alarm_types = {}
            for alarm_type in [1, 2]:  # 1-火灾，2-烟雾
                type_count = df[df['alarm_type'] == alarm_type]['count'].sum()
                alarm_types[alarm_type] = int(type_count)
            
            # 按级别统计
            alarm_levels = {}
            for alarm_level in [1, 2, 3]:  # 1-低，2-中，3-高
                level_count = df[df['alarm_level'] == alarm_level]['count'].sum()
                alarm_levels[alarm_level] = int(level_count)
            
            # 按日期统计
            daily_stats = {}
            for _, row in df.iterrows():
                date_str = row['alarm_date'].strftime('%Y-%m-%d') if isinstance(row['alarm_date'], datetime) else str(row['alarm_date'])
                if date_str not in daily_stats:
                    daily_stats[date_str] = {'fire': 0, 'smoke': 0, 'total': 0}
                
                # 更新对应类型的计数
                if row['alarm_type'] == 1:
                    daily_stats[date_str]['fire'] += int(row['count'])
                else:
                    daily_stats[date_str]['smoke'] += int(row['count'])
                daily_stats[date_str]['total'] += int(row['count'])
            
            # 确保每一天都有数据
            date_range = pd.date_range(start=start_date, end=end_date)
            complete_daily_stats = []
            
            for date in date_range:
                date_str = date.strftime('%Y-%m-%d')
                if date_str in daily_stats:
                    stats = daily_stats[date_str]
                else:
                    stats = {'fire': 0, 'smoke': 0, 'total': 0}
                
                complete_daily_stats.append({
                    'date': date_str,
                    **stats
                })
            
            # 格式化结果
            result = {
                'total_alarms': int(total_alarms),
                'alarm_types': {
                    'fire': alarm_types.get(1, 0),
                    'smoke': alarm_types.get(2, 0)
                },
                'alarm_levels': {
                    'low': alarm_levels.get(1, 0),
                    'medium': alarm_levels.get(2, 0),
                    'high': alarm_levels.get(3, 0)
                },
                'daily_stats': complete_daily_stats,
                'start_date': start_date.strftime('%Y-%m-%d'),
                'end_date': end_date.strftime('%Y-%m-%d')
            }
            
            return result
            
        except Exception as e:
            logger.error(f"获取报警统计信息失败: {str(e)}")
            return {
                'error': f"获取报警统计信息失败: {str(e)}"
            }
    
    def get_detailed_alarm_history(self, start_date: Optional[datetime] = None, 
                                end_date: Optional[datetime] = None,
                                alarm_type: Optional[int] = None,
                                device_id: Optional[int] = None,
                                processed: Optional[bool] = None,
                                limit: int = 100) -> List[Dict]:
        """
        获取详细报警历史记录
        
        参数:
            start_date: 开始日期
            end_date: 结束日期
            alarm_type: 报警类型 (1-火灾，2-烟雾)
            device_id: 设备ID
            processed: 是否已处理
            limit: 返回记录数量限制
            
        返回:
            List[Dict]: 报警记录列表
        """
        # 默认查询最近7天的数据
        if not end_date:
            end_date = datetime.now()
        if not start_date:
            start_date = end_date - timedelta(days=7)
            
        try:
            # 构建SQL查询
            sql = """
            SELECT 
                a.*, 
                d.device_name 
            FROM 
                jens_alarms a 
            LEFT JOIN 
                jens_devices d ON a.device_id = d.id
            WHERE 
                a.alarm_time BETWEEN %s AND %s
            """
            params = [start_date, end_date]
            
            # 添加可选过滤条件
            if alarm_type is not None:
                sql += " AND a.alarm_type = %s"
                params.append(alarm_type)
            
            if device_id is not None:
                sql += " AND a.device_id = %s"
                params.append(device_id)
            
            if processed is not None:
                sql += " AND a.processed = %s"
                params.append(1 if processed else 0)
            
            sql += " ORDER BY a.alarm_time DESC LIMIT %s"
            params.append(limit)
            
            # 执行查询
            records = self.db.execute_query(sql, tuple(params))
            
            # 格式化结果
            formatted_records = []
            for record in records:
                # 将报警类型转换为可读形式
                if record['alarm_type'] == 1:
                    record['alarm_type_name'] = '火灾'
                else:
                    record['alarm_type_name'] = '烟雾'
                    
                # 将报警级别转换为可读形式
                if record['alarm_level'] == 1:
                    record['alarm_level_name'] = '低'
                elif record['alarm_level'] == 2:
                    record['alarm_level_name'] = '中'
                else:
                    record['alarm_level_name'] = '高'
                
                # 格式化时间
                if record['alarm_time']:
                    record['alarm_time_str'] = record['alarm_time'].strftime('%Y-%m-%d %H:%M:%S')
                if record['process_time']:
                    record['process_time_str'] = record['process_time'].strftime('%Y-%m-%d %H:%M:%S')
                
                formatted_records.append(record)
            
            return formatted_records
            
        except Exception as e:
            logger.error(f"获取详细报警历史失败: {str(e)}")
            return []
    
    def generate_alarm_trend_chart(self, start_date: Optional[datetime] = None, 
                               end_date: Optional[datetime] = None,
                               save_path: Optional[str] = None) -> str:
        """
        生成报警趋势图表
        
        参数:
            start_date: 开始日期
            end_date: 结束日期
            save_path: 保存路径，默认为报表目录下的自动生成文件名
            
        返回:
            str: 图表文件路径
        """
        # 获取报警统计数据
        stats = self.get_alarm_stats(start_date, end_date)
        
        if 'error' in stats:
            logger.error(f"生成趋势图表失败: {stats['error']}")
            return ""
        
        try:
            # 准备数据
            dates = [item['date'] for item in stats['daily_stats']]
            fire_counts = [item['fire'] for item in stats['daily_stats']]
            smoke_counts = [item['smoke'] for item in stats['daily_stats']]
            total_counts = [item['total'] for item in stats['daily_stats']]
            
            # 转换为日期对象
            date_objects = [datetime.strptime(d, '%Y-%m-%d') for d in dates]
            
            # 创建图表
            plt.figure(figsize=(12, 6))
            
            # 绘制折线图
            plt.plot(date_objects, total_counts, 'o-', label='总报警数', color='blue', linewidth=2)
            plt.plot(date_objects, fire_counts, 'o-', label='火灾报警', color='red', linewidth=2)
            plt.plot(date_objects, smoke_counts, 'o-', label='烟雾报警', color='gray', linewidth=2)
            
            # 设置图表标题和标签
            plt.title('报警趋势分析', fontsize=16)
            plt.xlabel('日期', fontsize=12)
            plt.ylabel('报警次数', fontsize=12)
            
            # 设置x轴日期格式
            plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
            plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator())
            
            # 添加网格线
            plt.grid(True, linestyle='--', alpha=0.7)
            
            # 添加图例
            plt.legend()
            
            # 自适应美化布局
            plt.tight_layout()
            
            # 保存图表
            if not save_path:
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                save_path = str(self.report_dir / f"alarm_trend_{timestamp}.png")
                
            plt.savefig(save_path, dpi=100)
            plt.close()
            
            logger.info(f"报警趋势图表已生成: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"生成报警趋势图表失败: {str(e)}")
            return ""
    
    def generate_alarm_distribution_chart(self, start_date: Optional[datetime] = None, 
                                    end_date: Optional[datetime] = None,
                                    save_path: Optional[str] = None) -> str:
        """
        生成报警分布饼图
        
        参数:
            start_date: 开始日期
            end_date: 结束日期
            save_path: 保存路径，默认为报表目录下的自动生成文件名
            
        返回:
            str: 图表文件路径
        """
        # 获取报警统计数据
        stats = self.get_alarm_stats(start_date, end_date)
        
        if 'error' in stats:
            logger.error(f"生成分布图表失败: {stats['error']}")
            return ""
        
        try:
            # 创建图表
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
            
            # 报警类型分布
            type_labels = ['火灾报警', '烟雾报警']
            type_values = [stats['alarm_types']['fire'], stats['alarm_types']['smoke']]
            type_colors = ['red', 'gray']
            type_explode = (0.1, 0)  # 突出显示火灾报警
            
            # 绘制饼图
            ax1.pie(type_values, labels=type_labels, colors=type_colors, 
                  autopct='%1.1f%%', startangle=90, explode=type_explode,
                  shadow=True, wedgeprops={'edgecolor': 'w'})
            ax1.set_title('报警类型分布')
            
            # 报警级别分布
            level_labels = ['低级报警', '中级报警', '高级报警']
            level_values = [stats['alarm_levels']['low'], 
                          stats['alarm_levels']['medium'], 
                          stats['alarm_levels']['high']]
            level_colors = ['green', 'orange', 'red']
            level_explode = (0, 0, 0.1)  # 突出显示高级报警
            
            # 绘制饼图
            ax2.pie(level_values, labels=level_labels, colors=level_colors, 
                  autopct='%1.1f%%', startangle=90, explode=level_explode,
                  shadow=True, wedgeprops={'edgecolor': 'w'})
            ax2.set_title('报警级别分布')
            
            # 添加图表标题
            plt.suptitle(f"报警分布统计 ({stats['start_date']} 至 {stats['end_date']})", fontsize=16)
            
            # 自适应美化布局
            plt.tight_layout()
            
            # 保存图表
            if not save_path:
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                save_path = str(self.report_dir / f"alarm_distribution_{timestamp}.png")
                
            plt.savefig(save_path, dpi=100)
            plt.close()
            
            logger.info(f"报警分布图表已生成: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"生成报警分布图表失败: {str(e)}")
            return ""
    
    def generate_system_performance_chart(self, days: int = 7, save_path: Optional[str] = None) -> str:
        """
        生成系统性能报表
        
        参数:
            days: 统计天数
            save_path: 保存路径，默认为报表目录下的自动生成文件名
            
        返回:
            str: 图表文件路径
        """
        try:
            # 查询系统性能记录
            sql = """
            SELECT 
                timestamp, cpu_usage, memory_usage, disk_usage
            FROM 
                jens_system_monitor
            WHERE 
                timestamp >= DATE_SUB(NOW(), INTERVAL %s DAY)
            ORDER BY 
                timestamp ASC
            """
            
            performance_data = self.db.execute_query(sql, (days,))
            
            if not performance_data:
                logger.warning(f"没有找到系统性能记录数据")
                return ""
            
            # 转换为DataFrame
            df = pd.DataFrame(performance_data)
            
            # 创建图表
            plt.figure(figsize=(12, 8))
            
            # 创建三个子图
            fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 12), sharex=True)
            
            # 1. CPU使用率
            ax1.plot(df['timestamp'], df['cpu_usage'], 'r-', linewidth=2)
            ax1.set_title('CPU使用率 (%)')
            ax1.set_ylim(0, 100)
            ax1.axhline(y=80, color='orange', linestyle='--')  # 警告线
            ax1.axhline(y=90, color='red', linestyle='--')     # 严重线
            ax1.fill_between(df['timestamp'], df['cpu_usage'], color='lightcoral', alpha=0.3)
            ax1.grid(True)
            
            # 2. 内存使用率
            ax2.plot(df['timestamp'], df['memory_usage'], 'b-', linewidth=2)
            ax2.set_title('内存使用率 (%)')
            ax2.set_ylim(0, 100)
            ax2.axhline(y=80, color='orange', linestyle='--')  # 警告线
            ax2.axhline(y=90, color='red', linestyle='--')     # 严重线
            ax2.fill_between(df['timestamp'], df['memory_usage'], color='lightblue', alpha=0.3)
            ax2.grid(True)
            
            # 3. 磁盘使用率
            ax3.plot(df['timestamp'], df['disk_usage'], 'g-', linewidth=2)
            ax3.set_title('磁盘使用率 (%)')
            ax3.set_ylim(0, 100)
            ax3.axhline(y=85, color='orange', linestyle='--')  # 警告线
            ax3.axhline(y=95, color='red', linestyle='--')     # 严重线
            ax3.fill_between(df['timestamp'], df['disk_usage'], color='lightgreen', alpha=0.3)
            ax3.grid(True)
            
            # 设置x轴格式
            plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
            plt.gcf().autofmt_xdate()
            
            # 添加图表标题
            plt.suptitle(f"系统性能监控报表 (最近{days}天)", fontsize=16)
            
            # 自适应美化布局
            plt.tight_layout()
            
            # 保存图表
            if not save_path:
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                save_path = str(self.report_dir / f"system_performance_{timestamp}.png")
                
            plt.savefig(save_path, dpi=100)
            plt.close()
            
            logger.info(f"系统性能图表已生成: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"生成系统性能图表失败: {str(e)}")
            return ""
    
    def generate_excel_report(self, start_date: Optional[datetime] = None, 
                          end_date: Optional[datetime] = None,
                          save_path: Optional[str] = None) -> str:
        """
        生成Excel格式详细报表
        
        参数:
            start_date: 开始日期
            end_date: 结束日期
            save_path: 保存路径，默认为报表目录下的自动生成文件名
            
        返回:
            str: 报表文件路径
        """
        try:
            # 获取报警记录
            alarm_records = self.get_detailed_alarm_history(start_date, end_date, limit=10000)
            
            if not alarm_records:
                logger.warning(f"没有找到报警记录数据")
                return ""
            
            # 转换为DataFrame
            alarm_df = pd.DataFrame(alarm_records)
            
            # 创建Excel writer
            if not save_path:
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                save_path = str(self.report_dir / f"alarm_report_{timestamp}.xlsx")
            
            writer = pd.ExcelWriter(save_path, engine='openpyxl')
            
            # 1. 报警记录表
            alarm_df_export = alarm_df[[
                'id', 'alarm_time_str', 'device_name', 'alarm_type_name', 'alarm_level_name',
                'confidence', 'processed', 'process_time_str', 'process_user', 'process_note'
            ]].copy()
            
            # 重命名列
            alarm_df_export.columns = [
                '报警ID', '报警时间', '设备名称', '报警类型', '报警级别',
                '置信度', '是否已处理', '处理时间', '处理人', '处理备注'
            ]
            
            # 格式化处理状态
            alarm_df_export['是否已处理'] = alarm_df_export['是否已处理'].map(lambda x: '已处理' if x == 1 else '未处理')
            
            # 写入Excel
            alarm_df_export.to_excel(writer, sheet_name='报警记录', index=False)
            
            # 2. 生成统计表
            stats = self.get_alarm_stats(start_date, end_date)
            
            # 按天统计数据
            daily_df = pd.DataFrame(stats['daily_stats'])
            daily_df.columns = ['日期', '火灾报警数', '烟雾报警数', '总报警数']
            daily_df.to_excel(writer, sheet_name='每日统计', index=False)
            
            # 3. 报警类型汇总
            type_data = {
                '报警类型': ['火灾报警', '烟雾报警', '总计'],
                '数量': [
                    stats['alarm_types']['fire'],
                    stats['alarm_types']['smoke'],
                    stats['total_alarms']
                ],
                '占比': [
                    f"{stats['alarm_types']['fire'] / stats['total_alarms'] * 100:.1f}%" if stats['total_alarms'] > 0 else "0.0%",
                    f"{stats['alarm_types']['smoke'] / stats['total_alarms'] * 100:.1f}%" if stats['total_alarms'] > 0 else "0.0%",
                    "100.0%"
                ]
            }
            type_df = pd.DataFrame(type_data)
            type_df.to_excel(writer, sheet_name='报警类型统计', index=False)
            
            # 4. 报警级别汇总
            level_data = {
                '报警级别': ['低级', '中级', '高级', '总计'],
                '数量': [
                    stats['alarm_levels']['low'],
                    stats['alarm_levels']['medium'],
                    stats['alarm_levels']['high'],
                    stats['total_alarms']
                ],
                '占比': [
                    f"{stats['alarm_levels']['low'] / stats['total_alarms'] * 100:.1f}%" if stats['total_alarms'] > 0 else "0.0%",
                    f"{stats['alarm_levels']['medium'] / stats['total_alarms'] * 100:.1f}%" if stats['total_alarms'] > 0 else "0.0%",
                    f"{stats['alarm_levels']['high'] / stats['total_alarms'] * 100:.1f}%" if stats['total_alarms'] > 0 else "0.0%",
                    "100.0%"
                ]
            }
            level_df = pd.DataFrame(level_data)
            level_df.to_excel(writer, sheet_name='报警级别统计', index=False)
            
            # 保存Excel文件
            writer._save()
            
            logger.info(f"Excel报表已生成: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"生成Excel报表失败: {str(e)}")
            return ""
    
    def search_alarms(self, query: str, start_date: Optional[datetime] = None,
                    end_date: Optional[datetime] = None, limit: int = 100) -> List[Dict]:
        """
        搜索报警记录
        
        参数:
            query: 搜索关键词
            start_date: 开始日期
            end_date: 结束日期
            limit: 返回记录数量限制
            
        返回:
            List[Dict]: 符合条件的报警记录列表
        """
        # 默认查询最近30天的数据
        if not end_date:
            end_date = datetime.now()
        if not start_date:
            start_date = end_date - timedelta(days=30)
            
        try:
            # 构建搜索SQL
            sql = """
            SELECT 
                a.*, 
                d.device_name 
            FROM 
                jens_alarms a 
            LEFT JOIN 
                jens_devices d ON a.device_id = d.id
            WHERE 
                a.alarm_time BETWEEN %s AND %s
                AND (
                    d.device_name LIKE %s
                    OR a.process_note LIKE %s
                    OR a.process_user LIKE %s
                )
            ORDER BY 
                a.alarm_time DESC
            LIMIT %s
            """
            
            search_param = f"%{query}%"
            params = (start_date, end_date, search_param, search_param, search_param, limit)
            
            # 执行查询
            records = self.db.execute_query(sql, params)
            
            # 格式化结果
            formatted_records = []
            for record in records:
                # 将报警类型转换为可读形式
                if record['alarm_type'] == 1:
                    record['alarm_type_name'] = '火灾'
                else:
                    record['alarm_type_name'] = '烟雾'
                    
                # 将报警级别转换为可读形式
                if record['alarm_level'] == 1:
                    record['alarm_level_name'] = '低'
                elif record['alarm_level'] == 2:
                    record['alarm_level_name'] = '中'
                else:
                    record['alarm_level_name'] = '高'
                
                # 格式化时间
                if record['alarm_time']:
                    record['alarm_time_str'] = record['alarm_time'].strftime('%Y-%m-%d %H:%M:%S')
                if record['process_time']:
                    record['process_time_str'] = record['process_time'].strftime('%Y-%m-%d %H:%M:%S')
                
                formatted_records.append(record)
            
            return formatted_records
            
        except Exception as e:
            logger.error(f"搜索报警记录失败: {str(e)}")
            return []
        
    def get_device_alarm_stats(self) -> List[Dict]:
        """
        获取设备报警统计信息
        
        返回:
            List[Dict]: 设备报警统计信息列表
        """
        try:
            # 构建SQL
            sql = """
            SELECT 
                d.id,
                d.device_name,
                d.device_type,
                COUNT(a.id) AS total_alarms,
                SUM(CASE WHEN a.alarm_type = 1 THEN 1 ELSE 0 END) AS fire_alarms,
                SUM(CASE WHEN a.alarm_type = 2 THEN 1 ELSE 0 END) AS smoke_alarms,
                SUM(CASE WHEN a.alarm_level = 3 THEN 1 ELSE 0 END) AS high_level_alarms,
                MAX(a.alarm_time) AS last_alarm_time
            FROM 
                jens_devices d
            LEFT JOIN 
                jens_alarms a ON d.id = a.device_id
            GROUP BY 
                d.id, d.device_name, d.device_type
            ORDER BY 
                total_alarms DESC
            """
            
            # 执行查询
            device_stats = self.db.execute_query(sql)
            
            # 格式化结果
            for stat in device_stats:
                # 格式化最后报警时间
                if stat['last_alarm_time']:
                    stat['last_alarm_time_str'] = stat['last_alarm_time'].strftime('%Y-%m-%d %H:%M:%S')
                else:
                    stat['last_alarm_time_str'] = '无报警记录'
            
            return device_stats
            
        except Exception as e:
            logger.error(f"获取设备报警统计信息失败: {str(e)}")
            return []


# 单例模式
_data_analytics_instance = None

def get_data_analytics() -> DataAnalytics:
    """
    获取数据分析器单例
    
    返回:
        DataAnalytics: 数据分析器实例
    """
    global _data_analytics_instance
    
    if _data_analytics_instance is None:
        _data_analytics_instance = DataAnalytics()
    
    return _data_analytics_instance 