-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS jens_fire_smoke DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE jens_fire_smoke;

-- 创建设备表
CREATE TABLE IF NOT EXISTS `jens_devices` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `device_name` VARCHAR(100) NOT NULL COMMENT '设备名称',
  `device_type` VARCHAR(50) NOT NULL COMMENT '设备类型',
  `ip_address` VARCHAR(50) NULL COMMENT 'IP地址',
  `port` INT NULL COMMENT '端口号',
  `username` VARCHAR(50) NULL COMMENT '用户名',
  `password` VARCHAR(100) NULL COMMENT '密码',
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '设备状态：0-离线，1-在线',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `device_name_UNIQUE` (`device_name` ASC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备信息表';

-- 创建报警事件表
CREATE TABLE IF NOT EXISTS `jens_alarms` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `device_id` INT NOT NULL COMMENT '设备ID',
  `alarm_type` TINYINT NOT NULL COMMENT '报警类型：1-火焰，2-烟雾',
  `confidence` FLOAT NOT NULL COMMENT '置信度',
  `alarm_level` TINYINT NOT NULL COMMENT '报警级别：1-低，2-中，3-高',
  `image_path` VARCHAR(255) NULL COMMENT '报警图片路径',
  `video_path` VARCHAR(255) NULL COMMENT '报警视频路径',
  `processed` TINYINT NOT NULL DEFAULT 0 COMMENT '是否处理：0-未处理，1-已处理',
  `process_note` VARCHAR(500) NULL COMMENT '处理备注',
  `process_time` DATETIME NULL COMMENT '处理时间',
  `process_user` VARCHAR(50) NULL COMMENT '处理人',
  `alarm_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报警时间',
  PRIMARY KEY (`id`),
  INDEX `idx_device_id` (`device_id` ASC),
  INDEX `idx_alarm_time` (`alarm_time` ASC),
  CONSTRAINT `fk_alarm_device` FOREIGN KEY (`device_id`) REFERENCES `jens_devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报警事件表';

-- 创建用户表
CREATE TABLE IF NOT EXISTS `jens_users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `password` VARCHAR(100) NOT NULL COMMENT '密码',
  `real_name` VARCHAR(50) NULL COMMENT '真实姓名',
  `email` VARCHAR(100) NULL COMMENT '邮箱',
  `phone` VARCHAR(20) NULL COMMENT '电话',
  `role` TINYINT NOT NULL DEFAULT 2 COMMENT '角色：1-管理员，2-普通用户',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `last_login` DATETIME NULL COMMENT '最后登录时间',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 创建系统配置表
CREATE TABLE IF NOT EXISTS `jens_configs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `config_key` VARCHAR(50) NOT NULL COMMENT '配置键',
  `config_value` VARCHAR(500) NOT NULL COMMENT '配置值',
  `description` VARCHAR(200) NULL COMMENT '配置描述',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `config_key_UNIQUE` (`config_key` ASC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';

-- 创建报警记录统计表（用于快速查询统计数据）
CREATE TABLE IF NOT EXISTS `jens_alarm_stats` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `stat_date` DATE NOT NULL COMMENT '统计日期',
  `alarm_type` TINYINT NOT NULL COMMENT '报警类型：1-火焰，2-烟雾',
  `alarm_count` INT NOT NULL DEFAULT 0 COMMENT '报警次数',
  `processed_count` INT NOT NULL DEFAULT 0 COMMENT '已处理次数',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `stat_date_type_UNIQUE` (`stat_date` ASC, `alarm_type` ASC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报警统计表';

-- 初始数据：创建默认管理员账户（用户名：admin，密码：admin123）
-- 注意：实际应用中应该对密码进行加密存储
INSERT INTO `jens_users` (`username`, `password`, `real_name`, `role`, `status`) 
VALUES ('admin', 'admin123', '系统管理员', 1, 1)
ON DUPLICATE KEY UPDATE `update_time` = CURRENT_TIMESTAMP;

-- 初始配置数据
INSERT INTO `jens_configs` (`config_key`, `config_value`, `description`) VALUES
('system_name', 'JENS火灾烟雾报警系统', '系统名称'),
('alarm_sound_enabled', 'true', '是否启用声音报警'),
('notification_enabled', 'true', '是否启用桌面通知'),
('auto_start', 'true', '系统启动时自动运行'),
('max_storage_days', '30', '历史数据最大保存天数')
ON DUPLICATE KEY UPDATE `update_time` = CURRENT_TIMESTAMP;

-- 创建定时清理过期数据的事件
DELIMITER //
CREATE EVENT IF NOT EXISTS `evt_clean_old_alarms`
ON SCHEDULE EVERY 1 DAY STARTS (CURRENT_DATE + INTERVAL 1 DAY + INTERVAL 1 HOUR)
DO
BEGIN
    -- 删除超过保存期限的报警记录
    DELETE FROM `jens_alarms` 
    WHERE `alarm_time` < (NOW() - INTERVAL (
        SELECT CAST(`config_value` AS UNSIGNED) 
        FROM `jens_configs` 
        WHERE `config_key` = 'max_storage_days'
    ) DAY);
    
    -- 插入或更新统计数据
    INSERT INTO `jens_alarm_stats` (`stat_date`, `alarm_type`, `alarm_count`, `processed_count`)
    SELECT 
        DATE(`alarm_time`) as stat_date,
        `alarm_type`,
        COUNT(*) as alarm_count,
        SUM(CASE WHEN `processed` = 1 THEN 1 ELSE 0 END) as processed_count
    FROM `jens_alarms`
    WHERE DATE(`alarm_time`) = DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY)
    GROUP BY DATE(`alarm_time`), `alarm_type`
    ON DUPLICATE KEY UPDATE
        `alarm_count` = VALUES(`alarm_count`),
        `processed_count` = VALUES(`processed_count`),
        `update_time` = CURRENT_TIMESTAMP;
END //
DELIMITER ;

-- 创建存储过程：添加报警事件并更新统计
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_add_alarm_event`(
    IN p_device_id INT,
    IN p_alarm_type TINYINT,
    IN p_confidence FLOAT,
    IN p_alarm_level TINYINT,
    IN p_image_path VARCHAR(255),
    IN p_video_path VARCHAR(255)
)
BEGIN
    -- 插入报警事件
    INSERT INTO `jens_alarms` (
        `device_id`, 
        `alarm_type`,
        `confidence`, 
        `alarm_level`,
        `image_path`,
        `video_path`
    ) VALUES (
        p_device_id,
        p_alarm_type,
        p_confidence,
        p_alarm_level,
        p_image_path,
        p_video_path
    );
    
    -- 更新当日统计
    INSERT INTO `jens_alarm_stats` (`stat_date`, `alarm_type`, `alarm_count`)
    VALUES (CURRENT_DATE, p_alarm_type, 1)
    ON DUPLICATE KEY UPDATE
        `alarm_count` = `alarm_count` + 1,
        `update_time` = CURRENT_TIMESTAMP;
END //
DELIMITER ;

-- 创建存储过程：处理报警事件
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS `sp_process_alarm`(
    IN p_alarm_id INT,
    IN p_process_note VARCHAR(500),
    IN p_process_user VARCHAR(50)
)
BEGIN
    DECLARE v_alarm_type TINYINT;
    DECLARE v_stat_date DATE;
    
    -- 获取报警类型和日期
    SELECT `alarm_type`, DATE(`alarm_time`) INTO v_alarm_type, v_stat_date
    FROM `jens_alarms`
    WHERE `id` = p_alarm_id;
    
    -- 更新报警事件为已处理
    UPDATE `jens_alarms`
    SET 
        `processed` = 1,
        `process_note` = p_process_note,
        `process_user` = p_process_user,
        `process_time` = NOW()
    WHERE `id` = p_alarm_id;
    
    -- 更新统计数据
    UPDATE `jens_alarm_stats`
    SET 
        `processed_count` = `processed_count` + 1,
        `update_time` = CURRENT_TIMESTAMP
    WHERE `stat_date` = v_stat_date AND `alarm_type` = v_alarm_type;
END //
DELIMITER ; 