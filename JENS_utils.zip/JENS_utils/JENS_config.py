#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
配置文件处理模块
负责系统配置的读取和存储
"""

import os
import json
import logging
from pathlib import Path

class Config:
    """配置管理类"""
    _instance = None
    _config = None
    _config_file = "config.json"
    
    def __new__(cls, *args, **kwargs):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """初始化配置"""
        if self._config is None:
            self._load_config()
    
    def _get_config_path(self):
        """获取配置文件路径"""
        # 获取应用根目录
        app_dir = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        return app_dir / self._config_file
    
    def _load_config(self):
        """加载配置文件"""
        config_path = self._get_config_path()
        
        # 默认配置
        default_config = {
            "app": {
                "name": "JENS火灾烟雾报警系统",
                "version": "1.0.0",
                "log_level": "INFO"
            },
            "database": {
                "host": "localhost",
                "port": 3306,
                "user": "root",
                "password": "root",
                "database": "jens_fire_smoke",
                "charset": "utf8mb4"
            },
            "camera": {
                "default_resolution": [640, 480],
                "default_fps": 30
            },
            "detector": {
                "model_path": "JENS_models/yolov5s.pt",
                "confidence_threshold": 0.5,
                "device": "cpu"  # 'cpu' 或 'cuda'
            },
            "alarm": {
                "sound_enabled": True,
                "sound_file": "JENS_assets/sounds/alarm.wav",
                "notification_enabled": True,
                "alarm_confidence_thresholds": {
                    "low": 0.5,
                    "medium": 0.7,
                    "high": 0.9
                }
            },
            "storage": {
                "alarm_images_dir": "JENS_storage/images",
                "alarm_videos_dir": "JENS_storage/videos",
                "max_storage_days": 30
            }
        }
        
        # 如果配置文件存在，则加载
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    # 合并配置
                    self._config = self._merge_configs(default_config, loaded_config)
                    logging.info(f"配置文件加载成功: {config_path}")
            except Exception as e:
                logging.error(f"配置文件加载失败: {str(e)}")
                self._config = default_config
        else:
            # 配置文件不存在，使用默认配置并创建配置文件
            self._config = default_config
            self._save_config()
            logging.info(f"创建默认配置文件: {config_path}")
    
    def _merge_configs(self, default_config, loaded_config):
        """合并配置，确保所有默认配置项都存在"""
        merged = default_config.copy()
        
        for key, value in loaded_config.items():
            if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
                merged[key] = self._merge_configs(merged[key], value)
            else:
                merged[key] = value
        
        return merged
    
    def _save_config(self):
        """保存配置到文件"""
        config_path = self._get_config_path()
        try:
            # 确保配置目录存在
            config_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, indent=4, ensure_ascii=False)
            
            logging.info(f"配置文件保存成功: {config_path}")
            return True
        except Exception as e:
            logging.error(f"配置文件保存失败: {str(e)}")
            return False
    
    def get_config(self, section=None):
        """获取配置
        Args:
            section: 配置节名称，如果为None则返回全部配置
        Returns:
            配置字典
        """
        if section:
            return self._config.get(section, {})
        return self._config
    
    def get_db_config(self):
        """获取数据库配置
        Returns:
            数据库配置字典
        """
        return self.get_config("database")
    
    def set_config(self, section, key, value):
        """设置配置项
        Args:
            section: 配置节名称
            key: 配置键
            value: 配置值
        Returns:
            是否设置成功
        """
        if section not in self._config:
            self._config[section] = {}
        
        self._config[section][key] = value
        return self._save_config()
    
    def update_db_config(self, **kwargs):
        """更新数据库配置
        Args:
            **kwargs: 数据库配置参数，如host、port、user等
        Returns:
            是否更新成功
        """
        db_config = self.get_db_config()
        for key, value in kwargs.items():
            if key in db_config:
                db_config[key] = value
        
        self._config["database"] = db_config
        return self._save_config()
