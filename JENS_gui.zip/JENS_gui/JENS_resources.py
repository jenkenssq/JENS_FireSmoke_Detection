#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
JENS火灾烟雾报警系统资源文件
用于集中管理UI资源，如图标、样式表等
"""

import os
from pathlib import Path
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import QFile, QTextStream

# 基础路径
BASE_DIR = Path(__file__).parent.parent
ASSETS_DIR = BASE_DIR / "JENS_assets"
ICONS_DIR = ASSETS_DIR / "icons"
SOUNDS_DIR = ASSETS_DIR / "sounds"

# 图标资源
class Icons:
    """图标资源类"""
    
    # 应用图标
    APP = str(ICONS_DIR / "app.png")
    
    # 操作图标
    START = str(ICONS_DIR / "start.png")
    STOP = str(ICONS_DIR / "stop.png")
    SETTINGS = str(ICONS_DIR / "settings.png")
    CAMERA = str(ICONS_DIR / "camera.png")
    OPEN = str(ICONS_DIR / "open.png")
    SAVE = str(ICONS_DIR / "save.png")
    EXIT = str(ICONS_DIR / "exit.png")
    
    # 报警图标
    ALARM = str(ICONS_DIR / "alarm.png")
    WARNING = str(ICONS_DIR / "warning.png")
    NORMAL = str(ICONS_DIR / "normal.png")
    
    @staticmethod
    def get_icon(name):
        """获取图标对象"""
        try:
            icon_path = getattr(Icons, name.upper())
            if os.path.exists(icon_path):
                return QIcon(icon_path)
        except (AttributeError, TypeError):
            pass
        return QIcon()

# 样式表
class StyleSheets:
    """样式表资源类"""
    
    @staticmethod
    def load_stylesheet(name):
        """加载样式表文件"""
        try:
            style_path = ASSETS_DIR / "styles" / f"{name}.qss"
            if style_path.exists():
                style_file = QFile(str(style_path))
                if style_file.open(QFile.ReadOnly | QFile.Text):
                    stream = QTextStream(style_file)
                    return stream.readAll()
            return ""
        except Exception:
            return ""
    
    # 主题样式
    DARK = """
    /* 深色主题样式 */
    QMainWindow, QDialog {
        background-color: #2d2d2d;
        color: #f0f0f0;
    }
    
    QLabel {
        color: #f0f0f0;
    }
    
    QPushButton {
        background-color: #3d3d3d;
        color: #f0f0f0;
        border: 1px solid #5d5d5d;
        border-radius: 3px;
        padding: 5px 10px;
    }
    
    QPushButton:hover {
        background-color: #4d4d4d;
    }
    
    QPushButton:pressed {
        background-color: #5d5d5d;
    }
    
    QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox {
        background-color: #3d3d3d;
        color: #f0f0f0;
        border: 1px solid #5d5d5d;
        border-radius: 3px;
        padding: 3px;
    }
    
    QGroupBox {
        border: 1px solid #5d5d5d;
        border-radius: 5px;
        margin-top: 1ex;
        color: #f0f0f0;
    }
    
    QGroupBox::title {
        subcontrol-origin: margin;
        subcontrol-position: top center;
        padding: 0 5px;
    }
    
    QTabWidget::pane {
        border: 1px solid #5d5d5d;
        border-radius: 3px;
    }
    
    QTabBar::tab {
        background-color: #3d3d3d;
        color: #f0f0f0;
        border: 1px solid #5d5d5d;
        border-bottom: none;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        padding: 5px 10px;
    }
    
    QTabBar::tab:selected {
        background-color: #4d4d4d;
    }
    
    QTabBar::tab:hover {
        background-color: #4a4a4a;
    }
    
    QTableWidget {
        background-color: #2d2d2d;
        color: #f0f0f0;
        border: 1px solid #5d5d5d;
        gridline-color: #5d5d5d;
    }
    
    QHeaderView::section {
        background-color: #3d3d3d;
        color: #f0f0f0;
        border: 1px solid #5d5d5d;
    }
    
    QScrollBar {
        background-color: #2d2d2d;
        border: 1px solid #5d5d5d;
    }
    
    QStatusBar {
        background-color: #3d3d3d;
        color: #f0f0f0;
    }
    """
    
    LIGHT = """
    /* 浅色主题样式 */
    QMainWindow, QDialog {
        background-color: #f5f5f5;
        color: #333333;
    }
    
    QLabel {
        color: #333333;
    }
    
    QPushButton {
        background-color: #e0e0e0;
        color: #333333;
        border: 1px solid #c0c0c0;
        border-radius: 3px;
        padding: 5px 10px;
    }
    
    QPushButton:hover {
        background-color: #d0d0d0;
    }
    
    QPushButton:pressed {
        background-color: #c0c0c0;
    }
    
    QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox {
        background-color: #ffffff;
        color: #333333;
        border: 1px solid #c0c0c0;
        border-radius: 3px;
        padding: 3px;
    }
    
    QGroupBox {
        border: 1px solid #c0c0c0;
        border-radius: 5px;
        margin-top: 1ex;
        color: #333333;
    }
    
    QGroupBox::title {
        subcontrol-origin: margin;
        subcontrol-position: top center;
        padding: 0 5px;
    }
    
    QTabWidget::pane {
        border: 1px solid #c0c0c0;
        border-radius: 3px;
    }
    
    QTabBar::tab {
        background-color: #e0e0e0;
        color: #333333;
        border: 1px solid #c0c0c0;
        border-bottom: none;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        padding: 5px 10px;
    }
    
    QTabBar::tab:selected {
        background-color: #f5f5f5;
    }
    
    QTabBar::tab:hover {
        background-color: #e8e8e8;
    }
    
    QTableWidget {
        background-color: #ffffff;
        color: #333333;
        border: 1px solid #c0c0c0;
        gridline-color: #e0e0e0;
    }
    
    QHeaderView::section {
        background-color: #e0e0e0;
        color: #333333;
        border: 1px solid #c0c0c0;
    }
    
    QScrollBar {
        background-color: #f5f5f5;
        border: 1px solid #c0c0c0;
    }
    
    QStatusBar {
        background-color: #e0e0e0;
        color: #333333;
    }
    """
    
    # 报警状态样式
    ALARM_STYLE = """
    /* 报警状态样式 */
    #video_label {
        border: 3px solid red;
    }
    
    #alarm_label {
        color: white;
        background-color: red;
        font-weight: bold;
        padding: 5px;
        border-radius: 3px;
    }
    """
    
    WARNING_STYLE = """
    /* 警告状态样式 */
    #video_label {
        border: 3px solid orange;
    }
    
    #warning_label {
        color: white;
        background-color: orange;
        font-weight: bold;
        padding: 5px;
        border-radius: 3px;
    }
    """
    
    NORMAL_STYLE = """
    /* 正常状态样式 */
    #video_label {
        border: 1px solid #5d5d5d;
    }
    
    #normal_label {
        color: white;
        background-color: green;
        font-weight: bold;
        padding: 5px;
        border-radius: 3px;
    }
    """

# 声音资源
class Sounds:
    """声音资源类"""
    
    # 报警声音
    ALARM = str(SOUNDS_DIR / "JENS_alarm.wav")
    WARNING = str(SOUNDS_DIR / "JENS_warning.wav")
    
    @staticmethod
    def get_sound_path(name):
        """获取声音文件路径"""
        try:
            return getattr(Sounds, name.upper())
        except (AttributeError, TypeError):
            return None
