#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
JENS火灾烟雾报警系统主窗口模块
"""

import os
import sys
import cv2
import time
import numpy as np
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, Slot, Signal
from PySide6.QtGui import QImage, QPixmap, QIcon, QAction
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                              QLabel, QPushButton, QComboBox, QTabWidget, 
                              QStatusBar, QMenuBar, QMenu, QMessageBox, 
                              QFileDialog, QGroupBox, QGridLayout, QTableWidget, 
                              QTableWidgetItem, QHeaderView, QTableView)

from JENS_utils.JENS_config import Config
from JENS_utils.JENS_logger import get_logger
from JENS_camera import CameraManager, get_camera_manager
from JENS_gui.JENS_settings import SettingsDialog

# 导入检测器模块
try:
    from JENS_detector import YOLODetector
    DETECTOR_AVAILABLE = True
except ImportError:
    DETECTOR_AVAILABLE = False

logger = get_logger("JENS_main_window")


class MainWindow(QMainWindow):
    """主窗口类"""
    
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.camera_manager = get_camera_manager()
        self.detector = None
        
        # 初始化UI
        self.setup_ui()
        
        # 如果检测器可用，则初始化
        if DETECTOR_AVAILABLE:
            self.init_detector()
        
        # 启动定时器，用于刷新视频帧
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)  # 约33FPS
        
        # 加载保存的摄像头列表
        self.load_camera_list()
    
    def setup_ui(self):
        """设置UI界面"""
        # 窗口基本设置
        self.setWindowTitle("JENS火灾烟雾报警系统")
        self.setMinimumSize(1024, 768)
        
        # 设置应用图标
        icon_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            logger.info(f"已加载应用图标: {icon_path}")
        else:
            logger.warning(f"图标文件不存在: {icon_path}")
        
        # 创建中心widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QVBoxLayout(central_widget)
        
        # 上部：视频显示和控制区域
        top_layout = QHBoxLayout()
        
        # 左侧：视频显示
        video_group = QGroupBox("视频监控")
        video_layout = QVBoxLayout(video_group)
        
        self.video_label = QLabel("等待视频输入...")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("background-color: black; color: white;")
        self.video_label.setMinimumSize(640, 480)
        
        video_layout.addWidget(self.video_label)
        
        # 视频控制
        video_control_layout = QHBoxLayout()
        
        # 摄像头选择
        self.camera_combo = QComboBox()
        self.camera_combo.setMinimumWidth(200)
        self.camera_combo.currentIndexChanged.connect(self.on_camera_changed)
        
        # 控制按钮
        self.start_button = QPushButton("开始")
        self.start_button.clicked.connect(self.on_start_clicked)
        
        self.stop_button = QPushButton("停止")
        self.stop_button.clicked.connect(self.on_stop_clicked)
        self.stop_button.setEnabled(False)
        
        video_control_layout.addWidget(QLabel("选择摄像头:"))
        video_control_layout.addWidget(self.camera_combo)
        video_control_layout.addWidget(self.start_button)
        video_control_layout.addWidget(self.stop_button)
        video_control_layout.addStretch()
        
        video_layout.addLayout(video_control_layout)
        
        # 右侧：检测结果和状态
        status_group = QGroupBox("检测状态")
        status_layout = QVBoxLayout(status_group)
        
        # 检测状态
        self.status_label = QLabel("检测引擎: 未启动")
        self.fps_label = QLabel("FPS: 0")
        self.model_label = QLabel("当前模型: 未加载")
        self.detection_result_label = QLabel("未检测到异常")
        
        status_layout.addWidget(self.status_label)
        status_layout.addWidget(self.fps_label)
        status_layout.addWidget(self.model_label)
        status_layout.addWidget(self.detection_result_label)
        status_layout.addStretch()
        
        # 将左右两部分添加到上部布局
        top_layout.addWidget(video_group, 7)
        top_layout.addWidget(status_group, 3)
        
        # 将上部布局添加到主布局
        main_layout.addLayout(top_layout)
        
        # 下部：报警记录（预留）
        alarm_group = self.setup_alarm_history()
        
        main_layout.addWidget(alarm_group)
        
        # 设置状态栏
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("系统就绪")
        
        # 设置菜单栏
        self.setup_menu()
    
    def setup_menu(self):
        """设置菜单栏"""
        menubar = self.menuBar()
        
        # 文件菜单
        file_menu = menubar.addMenu("文件")
        
        open_video_action = QAction("打开视频文件", self)
        open_video_action.triggered.connect(self.open_video_file)
        file_menu.addAction(open_video_action)
        
        open_image_action = QAction("打开图片文件", self)
        open_image_action.triggered.connect(self.open_image_file)
        file_menu.addAction(open_image_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("退出", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # 设置菜单
        settings_menu = menubar.addMenu("设置")
        
        camera_action = QAction("摄像头管理", self)
        camera_action.triggered.connect(self.open_camera_settings)
        settings_menu.addAction(camera_action)
        
        detector_action = QAction("检测器设置", self)
        detector_action.triggered.connect(self.open_detector_settings)
        settings_menu.addAction(detector_action)
        
        # 帮助菜单
        help_menu = menubar.addMenu("帮助")
        
        about_action = QAction("关于", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def init_detector(self):
        """初始化检测器"""
        try:
            # 使用与JENS_detector.py中相同的绝对路径和文件名
            model_path = "D:\\监控系统\\JENS_FireSmoke_Detection\\JENS_models\\yolov5s_best.pt"
            
            # 检查模型文件是否存在
            if not os.path.exists(model_path):
                logger.warning(f"绝对路径模型不存在: {model_path}，尝试使用相对路径")
                # 尝试相对路径
                model_path = os.path.join("JENS_models", "yolov5s_best.pt")
                if not os.path.exists(model_path):
                    raise FileNotFoundError(f"模型文件不存在: {model_path}")
            
            self.detector = YOLODetector(model_path)
            self.status_label.setText(f"检测引擎: YOLOv5 已加载")
            
            # 更新模型标签，显示当前使用的模型文件名
            model_filename = os.path.basename(self.detector.model_path)
            self.model_label.setText(f"当前模型: {model_filename}")
            
            # 设置较低的置信度阈值，以提高检测灵敏度
            self.detector.set_conf_thres(0.3)
            
            # 启用增强检测模式
            self.detector.enable_enhanced_mode(True)
            
            logger.info(f"YOLOv5检测器初始化成功，使用模型: {model_filename}")
        except Exception as e:
            self.status_label.setText(f"检测引擎: 加载失败")
            self.model_label.setText(f"当前模型: 加载失败")
            logger.error(f"初始化检测器失败: {str(e)}")
            QMessageBox.warning(self, "警告", f"初始化检测器失败: {str(e)}")
    
    def load_camera_list(self):
        """加载摄像头列表"""
        try:
            self.camera_combo.clear()
            
            # 添加默认摄像头选项
            self.camera_combo.addItem("默认摄像头", 0)
            
            # 从数据库加载已保存的摄像头
            cameras = self.camera_manager.get_camera_list()
            for camera in cameras:
                self.camera_combo.addItem(camera['name'], camera['id'])
            
            logger.info(f"已加载 {len(cameras)} 个摄像头")
        except Exception as e:
            logger.error(f"加载摄像头列表失败: {str(e)}")
    
    def open_camera_settings(self):
        """打开摄像头设置对话框"""
        # 此功能预留给下一阶段实现
        QMessageBox.information(self, "提示", "摄像头管理功能将在下一阶段实现")
    
    def open_detector_settings(self):
        """打开检测器设置对话框"""
        # 此功能预留给下一阶段实现
        QMessageBox.information(self, "提示", "检测器设置功能将在下一阶段实现")
    
    def open_video_file(self):
        """打开视频文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择视频文件", "", 
            "视频文件 (*.mp4 *.avi *.mov *.mkv);;所有文件 (*.*)"
        )
        
        if file_path:
            # 停止当前摄像头
            self.on_stop_clicked()
            
            # 打开视频文件
            if self.camera_manager.open_video_file(file_path):
                self.statusbar.showMessage(f"已打开视频文件: {os.path.basename(file_path)}")
                self.start_button.setEnabled(False)
                self.stop_button.setEnabled(True)
            else:
                QMessageBox.warning(self, "错误", f"无法打开视频文件: {file_path}")
    
    def open_image_file(self):
        """打开图片文件并进行检测"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择图片文件", "", 
            "图片文件 (*.jpg *.jpeg *.png *.bmp);;所有文件 (*.*)"
        )
        
        if file_path:
            try:
                # 停止当前摄像头或视频播放
                self.on_stop_clicked()
                self.timer.stop()
                
                # 调用检测图片的函数
                self.detect_image(file_path)
            except Exception as e:
                logger.error(f"处理图片时出错: {str(e)}")
                QMessageBox.warning(self, "错误", f"处理图片时出错: {str(e)}")
            finally:
                # 恢复定时器，但不立即恢复视频（除非用户手动点击开始）
                self.timer.start(30)
    
    def detect_image(self, image_path):
        """对静态图片进行火灾和烟雾检测
        
        参数:
            image_path: 图片文件路径
        """
        try:
            # 检查检测器是否初始化
            if not self.detector:
                if DETECTOR_AVAILABLE:
                    self.init_detector()
                
                if not self.detector:
                    QMessageBox.warning(self, "错误", "检测器未初始化，无法进行检测")
                    return
            else:
                # 更新模型标签，确保显示正确的模型名称
                model_filename = os.path.basename(self.detector.model_path)
                self.model_label.setText(f"当前模型: {model_filename}")

            logger.info(f"开始检测图片: {image_path}")
            
            # 读取图片
            frame = cv2.imread(image_path)
            if frame is None:
                QMessageBox.warning(self, "错误", f"无法读取图片: {image_path}")
                return
            
            # 检查图像尺寸和通道数
            if len(frame.shape) != 3 or frame.shape[2] != 3:
                logger.warning(f"图像格式不符合要求: {frame.shape}，尝试转换")
                # 转换为三通道彩色图像
                if len(frame.shape) == 2:  # 灰度图像
                    frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
                elif frame.shape[2] == 4:  # 带Alpha通道
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            
            # 确保图像尺寸适中，过大的图像会影响检测速度和准确性
            max_dim = 1280  # 最大尺寸限制
            height, width = frame.shape[:2]
            if height > max_dim or width > max_dim:
                logger.info(f"图像尺寸过大 ({width}x{height})，调整大小")
                scale = max_dim / max(height, width)
                new_width = int(width * scale)
                new_height = int(height * scale)
                frame = cv2.resize(frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
                logger.info(f"已将图像调整为 {new_width}x{new_height}")
            
            # 提高图像对比度，可能有助于检测火焰和烟雾
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
            # 确保使用列表而非元组
            lab_planes = list(cv2.split(lab))
            lab_planes[0] = clahe.apply(lab_planes[0])
            lab = cv2.merge(lab_planes)
            enhanced_frame = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
            
            # 执行检测前显示状态
            self.statusbar.showMessage("正在进行火灾烟雾检测...", 1000)
            
            # 执行检测 - 同时使用原始帧和增强帧分别检测，取最佳结果
            result_frame, detections = self.detector.detect(frame.copy())
            enhanced_result_frame, enhanced_detections = self.detector.detect(enhanced_frame.copy())
            
            # 如果增强帧检测到的结果更好，则使用增强帧的结果
            if (not detections or len(detections) == 0) and enhanced_detections and len(enhanced_detections) > 0:
                logger.info("增强图像检测到火灾/烟雾")
                result_frame = enhanced_result_frame.copy()
                detections = enhanced_detections.copy()
            elif detections and enhanced_detections:
                # 如果两者都检测到，取置信度最高的
                max_orig_conf = max([d["confidence"] for d in detections], default=0)
                max_enhanced_conf = max([d["confidence"] for d in enhanced_detections], default=0)
                
                if max_enhanced_conf > max_orig_conf:
                    logger.info(f"使用增强图像检测结果 (置信度: {max_enhanced_conf:.2f} vs {max_orig_conf:.2f})")
                    result_frame = enhanced_result_frame.copy()
                    detections = enhanced_detections.copy()
            
            logger.info(f"检测完成，发现 {len(detections)} 个目标")
            
            # 创建一个按钮，允许用户快速返回到视频模式
            resume_btn = QPushButton("返回视频监控")
            resume_btn.clicked.connect(self.on_start_clicked)
            resume_btn.setMinimumWidth(150)
            
            # 找到视频控制布局并添加按钮
            for i in range(self.centralWidget().layout().count()):
                item = self.centralWidget().layout().itemAt(i)
                if isinstance(item, QHBoxLayout):
                    for j in range(item.count()):
                        if isinstance(item.itemAt(j).widget(), QGroupBox):
                            if item.itemAt(j).widget().title() == "视频监控":
                                for k in range(item.itemAt(j).widget().layout().count()):
                                    if isinstance(item.itemAt(j).widget().layout().itemAt(k), QHBoxLayout):
                                        # 如果按钮已存在，先移除
                                        for l in range(item.itemAt(j).widget().layout().itemAt(k).count()):
                                            widget = item.itemAt(j).widget().layout().itemAt(k).itemAt(l).widget()
                                            if isinstance(widget, QPushButton) and widget.text() == "返回视频监控":
                                                widget.deleteLater()
                                        
                                        item.itemAt(j).widget().layout().itemAt(k).addWidget(resume_btn)
                                        break
            
            # 更新检测结果显示
            if detections and len(detections) > 0:
                detection_info = []
                for det in detections:
                    class_name = det["class_name"]
                    confidence = det["confidence"]
                    detection_info.append(f"{class_name}: {confidence:.2f}")
                
                self.detection_result_label.setText(f"检测结果: {', '.join(detection_info)}")
                
                # 计算最高置信度，用于判断是否触发报警
                max_confidence = max([det["confidence"] for det in detections])
                
                # 如果检测到火灾或烟雾，更新UI状态
                from JENS_alarm import AlarmManager
                if max_confidence >= 0.6:  # 报警阈值
                    self.update_alarm_status(AlarmManager.ALARM_LEVEL_ALARM)
                elif max_confidence >= 0.4:  # 警告阈值
                    self.update_alarm_status(AlarmManager.ALARM_LEVEL_WARNING)
                
                # 提供保存选项
                result = QMessageBox.question(
                    self, 
                    "检测完成", 
                    f"检测到: {', '.join(detection_info)}\n是否保存检测结果图片?",
                    QMessageBox.Yes | QMessageBox.No
                )
                
                if result == QMessageBox.Yes:
                    self.save_detection_result(result_frame, image_path)
                    
                # 记录报警事件到数据库
                if max_confidence >= 0.4:  # 至少是警告级别
                    try:
                        from JENS_alarm import get_alarm_manager
                        alarm_manager = get_alarm_manager()
                        
                        # 获取检测到的最高置信度的类别
                        max_det = max(detections, key=lambda x: x["confidence"])
                        alarm_type = 1 if max_det["class_name"] == "fire" else 2  # 1-火焰 2-烟雾
                        
                        # 记录报警事件
                        alarm_manager.record_alarm(
                            alarm_type=alarm_type,
                            confidence=max_det["confidence"],
                            camera_id=0,  # 静态图片使用0作为相机ID
                            image_path=image_path
                        )
                    except Exception as e:
                        logger.error(f"记录图片报警事件失败: {str(e)}")
            else:
                self.detection_result_label.setText("未检测到火灾或烟雾")
                QMessageBox.information(self, "检测完成", "未检测到火灾或烟雾")
                self.update_alarm_status(0)  # 恢复正常状态
            
            # 显示检测结果图像
            self.display_image(result_frame)
            
            # 更新状态栏
            self.statusbar.showMessage(f"图片 {os.path.basename(image_path)} 检测完成")
            
        except Exception as e:
            logger.error(f"图片检测失败: {str(e)}")
            QMessageBox.warning(self, "错误", f"图片检测失败: {str(e)}")
    
    def display_image(self, frame):
        """在界面上显示图像
        
        参数:
            frame: OpenCV图像帧
        """
        if frame is None:
            return
            
        # 转换为Qt可显示的格式
        h, w, c = frame.shape
        bytes_per_line = 3 * w
        
        # 将BGR转为RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # 创建QImage
        q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        
        # 创建QPixmap并设置到标签
        pixmap = QPixmap.fromImage(q_img)
        
        # 根据标签大小调整图像大小
        label_size = self.video_label.size()
        pixmap = pixmap.scaled(label_size, Qt.KeepAspectRatio)
        
        self.video_label.setPixmap(pixmap)
        self.statusbar.showMessage(f"已加载图片并完成检测")
    
    def save_detection_result(self, frame, original_path):
        """保存检测结果图片
        
        参数:
            frame: 带有检测框的图像帧
            original_path: 原始图像路径
        """
        # 生成保存路径
        save_dir = Path("JENS_data/detection_results")
        save_dir.mkdir(parents=True, exist_ok=True)
        
        # 获取原文件名并添加时间戳
        basename = os.path.basename(original_path)
        filename, ext = os.path.splitext(basename)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        save_path = str(save_dir / f"{filename}_detected_{timestamp}{ext}")
        
        # 保存图像
        try:
            cv2.imwrite(save_path, frame)
            logger.info(f"检测结果图像已保存: {save_path}")
            QMessageBox.information(self, "保存成功", f"检测结果图像已保存: {save_path}")
        except Exception as e:
            logger.error(f"保存检测结果图像失败: {str(e)}")
            QMessageBox.warning(self, "错误", f"保存检测结果图像失败: {str(e)}")
    
    @Slot()
    def on_camera_changed(self, index):
        """摄像头选择改变时的处理"""
        if index < 0:
            return
        
        camera_id = self.camera_combo.currentData()
        logger.info(f"已选择摄像头ID: {camera_id}")
    
    @Slot()
    def on_start_clicked(self):
        """开始按钮点击处理"""
        camera_id = self.camera_combo.currentData()
        
        if self.camera_manager.set_active_camera(camera_id):
            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(True)
            self.statusbar.showMessage(f"已启动摄像头: {self.camera_combo.currentText()}")
            logger.info(f"已启动摄像头ID: {camera_id}")
        else:
            QMessageBox.warning(self, "错误", "无法启动选择的摄像头")
    
    @Slot()
    def on_stop_clicked(self):
        """停止按钮点击处理"""
        self.camera_manager.stop_active_camera()
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.statusbar.showMessage("已停止摄像头")
        logger.info("摄像头已停止")
    
    def update_frame(self):
        """更新视频帧"""
        frame = self.camera_manager.get_frame()
        
        if frame is None:
            return
        
        # 检测(如果检测器已初始化)
        detections = []
        if self.detector and frame is not None:
            try:
                # 更新模型标签，确保显示正确的模型名称
                model_filename = os.path.basename(self.detector.model_path)
                if self.model_label.text() != f"当前模型: {model_filename}":
                    self.model_label.setText(f"当前模型: {model_filename}")
                
                result_frame, detections = self.detector.detect(frame.copy())
                frame = result_frame.copy()
                
                # 更新检测结果显示
                if detections and len(detections) > 0:
                    detection_info = []
                    for det in detections:
                        class_name = det["class_name"]
                        confidence = det["confidence"]
                        detection_info.append(f"{class_name}: {confidence:.2f}")
                    
                    self.detection_result_label.setText(f"检测结果: {', '.join(detection_info)}")
                    
                    # 获取当前的摄像头ID
                    camera_id = self.camera_combo.currentData()
                    
                    # 导入报警模块
                    from JENS_alarm import get_alarm_manager
                    alarm_manager = get_alarm_manager()
                    
                    # 检查是否需要触发报警
                    alarm_level = alarm_manager.check_detection(detections.copy(), frame.copy(), camera_id)
                    
                    # 根据报警级别更新UI
                    self.update_alarm_status(alarm_level)
                else:
                    self.detection_result_label.setText("未检测到异常")
                    # 更新为正常状态
                    from JENS_alarm import AlarmManager
                    self.update_alarm_status(AlarmManager.ALARM_LEVEL_NORMAL)
            except Exception as e:
                logger.error(f"检测过程出错: {str(e)}")
        
        # 检测器未初始化时，直接显示原始帧
        
        # 转换为Qt可显示的格式
        h, w, c = frame.shape
        bytes_per_line = 3 * w
        
        # 将BGR转为RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # 创建QImage
        q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        
        # 创建QPixmap并设置到标签
        pixmap = QPixmap.fromImage(q_img)
        self.video_label.setPixmap(pixmap)
        
        # 更新FPS
        fps = self.camera_manager.get_active_camera_fps()
        self.fps_label.setText(f"FPS: {fps:.1f}")
        
        # 如果正在录制，添加帧到录制队列
        if hasattr(self, 'alarm_manager') and self.alarm_manager.video_writer is not None:
            self.alarm_manager.add_recording_frame(frame.copy())
    
    def update_alarm_status(self, alarm_level):
        """根据报警级别更新UI状态"""
        from JENS_alarm import AlarmManager
        from JENS_gui.JENS_resources import StyleSheets
        
        if alarm_level == AlarmManager.ALARM_LEVEL_ALARM:
            # 报警状态
            self.video_label.setStyleSheet(StyleSheets.ALARM_STYLE)
            self.statusbar.showMessage("警告：检测到危险！", 0)  # 0表示不会自动清除
            
            # 检查是否需要加载报警管理器
            if not hasattr(self, 'alarm_manager'):
                from JENS_alarm import get_alarm_manager
                self.alarm_manager = get_alarm_manager()
            
            # 更新报警历史记录
            self.load_alarm_history()
            
        elif alarm_level == AlarmManager.ALARM_LEVEL_WARNING:
            # 警告状态
            self.video_label.setStyleSheet(StyleSheets.WARNING_STYLE)
            self.statusbar.showMessage("注意：检测到潜在风险", 5000)
            
        else:
            # 正常状态
            self.video_label.setStyleSheet("")  # 清除样式
            self.statusbar.showMessage("系统正常运行中", 2000)
    
    def load_alarm_history(self):
        """加载并显示报警历史记录"""
        # 如果报警历史表格不存在，则创建
        if not hasattr(self, 'alarm_table'):
            return
        
        try:
            # 获取报警管理器
            from JENS_alarm import get_alarm_manager
            alarm_manager = get_alarm_manager()
            
            # 获取最近的报警记录
            alarms = alarm_manager.get_recent_alarms(limit=10)
            
            # 清空表格
            self.alarm_table.setRowCount(0)
            
            # 填充表格
            for i, alarm in enumerate(alarms):
                self.alarm_table.insertRow(i)
                
                # 时间
                alarm_time = QTableWidgetItem(alarm.get('alarm_time', '').strftime("%Y-%m-%d %H:%M:%S"))
                self.alarm_table.setItem(i, 0, alarm_time)
                
                # 类型
                alarm_type = "火焰" if alarm.get('alarm_type') == 1 else "烟雾"
                type_item = QTableWidgetItem(alarm_type)
                self.alarm_table.setItem(i, 1, type_item)
                
                # 置信度
                confidence = QTableWidgetItem(f"{alarm.get('confidence', 0):.2f}")
                self.alarm_table.setItem(i, 2, confidence)
                
                # 设备
                device_name = QTableWidgetItem(alarm.get('device_name', '未知设备'))
                self.alarm_table.setItem(i, 3, device_name)
                
                # 状态
                status = "已处理" if alarm.get('processed') == 1 else "未处理"
                status_item = QTableWidgetItem(status)
                self.alarm_table.setItem(i, 4, status_item)
                
        except Exception as e:
            logger.error(f"加载报警历史失败: {str(e)}")
            
    def setup_alarm_history(self):
        """设置报警历史表格"""
        # 下部：报警记录
        alarm_group = QGroupBox("报警记录")
        alarm_layout = QVBoxLayout(alarm_group)
        
        self.alarm_table = QTableWidget(0, 5)
        self.alarm_table.setHorizontalHeaderLabels(["时间", "类型", "置信度", "设备", "状态"])
        self.alarm_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.alarm_table.setSelectionBehavior(QTableView.SelectRows)
        
        # 添加表格
        alarm_layout.addWidget(self.alarm_table)
        
        # 添加按钮
        button_layout = QHBoxLayout()
        
        self.refresh_btn = QPushButton("刷新")
        self.refresh_btn.clicked.connect(self.load_alarm_history)
        
        self.clear_alarm_btn = QPushButton("清除报警")
        self.clear_alarm_btn.clicked.connect(self.clear_alarm)
        
        button_layout.addWidget(self.refresh_btn)
        button_layout.addWidget(self.clear_alarm_btn)
        button_layout.addStretch()
        
        alarm_layout.addLayout(button_layout)
        
        return alarm_group
    
    def clear_alarm(self):
        """清除当前报警状态"""
        try:
            # 获取报警管理器
            from JENS_alarm import get_alarm_manager
            alarm_manager = get_alarm_manager()
            
            # 重置报警状态
            alarm_manager.reset_alarm()
            
            # 更新UI
            self.update_alarm_status(0)  # 正常状态
            
            self.statusbar.showMessage("已清除报警状态", 3000)
        except Exception as e:
            logger.error(f"清除报警失败: {str(e)}")
            self.statusbar.showMessage(f"清除报警失败: {str(e)}", 3000)
    
    def show_about(self):
        """显示关于对话框"""
        QMessageBox.about(self, "关于", 
                          "JENS火灾烟雾报警系统 V1.0\n\n"
                          "基于PySide6和YOLOv5的实时火灾烟雾检测系统")
    
    def closeEvent(self, event):
        """窗口关闭事件处理"""
        # 停止摄像头
        self.camera_manager.stop_active_camera()
        logger.info("应用程序关闭，资源已释放")
        event.accept()

    def open_batch_images(self):
        """打开并批量检测多张图片"""
        file_paths, _ = QFileDialog.getOpenFileNames(
            self, "选择多个图片文件", "", 
            "图片文件 (*.jpg *.jpeg *.png *.bmp);;所有文件 (*.*)"
        )
        
        if file_paths and len(file_paths) > 0:
            try:
                # 停止当前摄像头或视频播放
                self.on_stop_clicked()
                self.timer.stop()
                
                # 调用批量检测图片的函数
                self.batch_detect_images(file_paths)
            except Exception as e:
                logger.error(f"批量处理图片时出错: {str(e)}")
                QMessageBox.warning(self, "错误", f"批量处理图片时出错: {str(e)}")
            finally:
                # 恢复定时器
                self.timer.start(30)
    
    def batch_detect_images(self, image_paths):
        """批量检测多张图片
        
        参数:
            image_paths: 图片文件路径列表
        """
        try:
            # 检查检测器是否初始化
            if not self.detector:
                if DETECTOR_AVAILABLE:
                    self.init_detector()
                
                if not self.detector:
                    QMessageBox.warning(self, "错误", "检测器未初始化，无法进行检测")
                    return
            else:
                # 更新模型标签，确保显示正确的模型名称
                model_filename = os.path.basename(self.detector.model_path)
                self.model_label.setText(f"当前模型: {model_filename}")
            
            # 创建存储检测结果的目录
            save_dir = Path("JENS_data/batch_detection_results")
            save_dir.mkdir(parents=True, exist_ok=True)
            
            # 创建报告文件
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            report_path = save_dir / f"batch_report_{timestamp}.txt"
            
            total_images = len(image_paths)
            detected_images = 0
            alarm_images = 0
            warning_images = 0
            
            # 开始批处理
            with open(report_path, "w", encoding="utf-8") as report_file:
                report_file.write(f"JENS火灾烟雾检测系统 - 批量检测报告\n")
                report_file.write(f"检测时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                report_file.write(f"检测图片数量: {total_images}\n")
                report_file.write(f"使用模型: {model_filename}\n")
                report_file.write("-" * 50 + "\n\n")
                
                for i, image_path in enumerate(image_paths):
                    try:
                        # 更新状态栏
                        self.statusbar.showMessage(f"正在处理: {i+1}/{total_images} - {os.path.basename(image_path)}")
                        
                        # 读取图片
                        frame = cv2.imread(image_path)
                        if frame is None:
                            report_file.write(f"图片 {os.path.basename(image_path)}: 无法读取\n")
                            continue
                        
                        # 图像预处理 - 与detect_image方法相同
                        # 检查图像尺寸和通道数
                        if len(frame.shape) != 3 or frame.shape[2] != 3:
                            logger.warning(f"图像格式不符合要求: {frame.shape}，尝试转换")
                            # 转换为三通道彩色图像
                            if len(frame.shape) == 2:  # 灰度图像
                                frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
                            elif frame.shape[2] == 4:  # 带Alpha通道
                                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                        
                        # 调整图像尺寸
                        max_dim = 1280  # 最大尺寸限制
                        height, width = frame.shape[:2]
                        if height > max_dim or width > max_dim:
                            scale = max_dim / max(height, width)
                            new_width = int(width * scale)
                            new_height = int(height * scale)
                            frame = cv2.resize(frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
                        
                        # 提高图像对比度
                        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
                        # 确保使用列表而非元组
                        lab_planes = list(cv2.split(lab))
                        lab_planes[0] = clahe.apply(lab_planes[0])
                        lab = cv2.merge(lab_planes)
                        enhanced_frame = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
                        
                        # 双重检测策略
                        result_frame, detections = self.detector.detect(frame.copy())
                        enhanced_result_frame, enhanced_detections = self.detector.detect(enhanced_frame.copy())
                        
                        # 选择最佳检测结果
                        if (not detections or len(detections) == 0) and enhanced_detections and len(enhanced_detections) > 0:
                            result_frame = enhanced_result_frame.copy()
                            detections = enhanced_detections.copy()
                            report_file.write(f"图片 {os.path.basename(image_path)}: 增强图像检测到目标\n")
                        elif detections and enhanced_detections:
                            # 如果两者都检测到，取置信度最高的
                            max_orig_conf = max([d["confidence"] for d in detections], default=0)
                            max_enhanced_conf = max([d["confidence"] for d in enhanced_detections], default=0)
                            
                            if max_enhanced_conf > max_orig_conf:
                                result_frame = enhanced_result_frame.copy()
                                detections = enhanced_detections.copy()
                                report_file.write(f"图片 {os.path.basename(image_path)}: 使用增强图像结果 ({max_enhanced_conf:.2f} vs {max_orig_conf:.2f})\n")
                        
                        # 显示当前处理的图片
                        self.display_image(result_frame)
                        
                        # 处理检测结果
                        if detections and len(detections) > 0:
                            detected_images += 1
                            detection_info = []
                            
                            for det in detections:
                                class_name = det["class_name"]
                                confidence = det["confidence"]
                                detection_info.append(f"{class_name}: {confidence:.2f}")
                            
                            # 写入报告
                            report_file.write(f"图片 {os.path.basename(image_path)}:\n")
                            report_file.write(f"  检测结果: {', '.join(detection_info)}\n")
                            
                            # 计算最高置信度
                            max_confidence = max([det["confidence"] for det in detections])
                            max_det = max(detections, key=lambda x: x["confidence"])
                            alarm_type = 1 if max_det["class_name"] == "fire" else 2  # 1-火焰 2-烟雾
                            
                            # 判断报警级别
                            if max_confidence >= 0.6:  # 报警级别
                                alarm_images += 1
                                report_file.write(f"  状态: 报警级别 (置信度: {max_confidence:.2f})\n")
                                
                                # 记录报警事件到数据库
                                try:
                                    from JENS_alarm import get_alarm_manager
                                    alarm_manager = get_alarm_manager()
                                    alarm_manager.record_alarm(
                                        alarm_type=alarm_type,
                                        confidence=max_confidence,
                                        camera_id=0,  # 静态图片使用0作为相机ID
                                        image_path=image_path
                                    )
                                except Exception as e:
                                    logger.error(f"记录图片报警事件失败: {str(e)}")
                                
                            elif max_confidence >= 0.4:  # 警告级别
                                warning_images += 1
                                report_file.write(f"  状态: 警告级别 (置信度: {max_confidence:.2f})\n")
                                
                                # 记录警告事件到数据库
                                try:
                                    from JENS_alarm import get_alarm_manager
                                    alarm_manager = get_alarm_manager()
                                    alarm_manager.record_alarm(
                                        alarm_type=alarm_type,
                                        confidence=max_confidence,
                                        camera_id=0,  # 静态图片使用0作为相机ID
                                        image_path=image_path
                                    )
                                except Exception as e:
                                    logger.error(f"记录图片警告事件失败: {str(e)}")
                            
                            else:
                                report_file.write(f"  状态: 正常 (置信度低于阈值)\n")
                            
                            # 保存检测结果图片
                            basename = os.path.basename(image_path)
                            filename, ext = os.path.splitext(basename)
                            result_path = str(save_dir / f"{filename}_detected{ext}")
                            cv2.imwrite(result_path, result_frame)
                            report_file.write(f"  结果图片: {result_path}\n\n")
                        else:
                            report_file.write(f"图片 {os.path.basename(image_path)}: 未检测到异常\n\n")
                    
                    except Exception as e:
                        logger.error(f"处理图片 {image_path} 时出错: {str(e)}")
                        report_file.write(f"图片 {os.path.basename(image_path)}: 处理失败 - {str(e)}\n\n")
                
                # 写入统计摘要
                report_file.write("\n" + "-" * 50 + "\n")
                report_file.write("检测结果统计:\n")
                report_file.write(f"总图片数: {total_images}\n")
                report_file.write(f"检测到异常的图片数: {detected_images}\n")
                report_file.write(f"报警级别图片数: {alarm_images}\n")
                report_file.write(f"警告级别图片数: {warning_images}\n")
                report_file.write(f"正常图片数: {total_images - detected_images}\n")
            
            # 更新报警历史记录表格
            self.load_alarm_history()
            
            # 显示完成信息
            QMessageBox.information(
                self, 
                "批量检测完成",
                f"已完成对 {total_images} 张图片的检测:\n"
                f"- 检测到异常: {detected_images} 张\n"
                f"- 报警级别: {alarm_images} 张\n"
                f"- 警告级别: {warning_images} 张\n"
                f"- 正常: {total_images - detected_images} 张\n\n"
                f"详细报告已保存到: {report_path}"
            )
            
            # 提示是否查看报告
            result = QMessageBox.question(
                self,
                "批量检测报告",
                "是否查看详细报告?",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if result == QMessageBox.Yes:
                # 使用系统默认应用打开报告
                import subprocess
                import platform
                
                if platform.system() == 'Windows':
                    os.startfile(str(report_path))
                elif platform.system() == 'Darwin':  # macOS
                    subprocess.call(('open', str(report_path)))
                else:  # Linux
                    subprocess.call(('xdg-open', str(report_path)))
            
        except Exception as e:
            logger.error(f"批量图片检测失败: {str(e)}")
            QMessageBox.warning(self, "错误", f"批量图片检测失败: {str(e)}")
