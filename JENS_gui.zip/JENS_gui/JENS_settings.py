#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
JENS火灾烟雾报警系统设置对话框
用于配置系统参数、摄像头设置等
"""

import os
from PySide6.QtCore import Qt, Signal, Slot
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (QDialog, QTabWidget, QVBoxLayout, QHBoxLayout, 
                              QLabel, QLineEdit, QPushButton, QComboBox,
                              QSpinBox, QDoubleSpinBox, QCheckBox, QGroupBox,
                              QFormLayout, QMessageBox, QFileDialog, QTableWidget,
                              QTableWidgetItem, QHeaderView, QWidget)

from JENS_utils.JENS_config import Config
from JENS_utils.JENS_logger import get_logger
from JENS_camera import get_camera_manager

logger = get_logger("JENS_settings")


class SettingsDialog(QDialog):
    """设置对话框类"""
    
    # 定义信号
    settings_changed = Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.config = Config()
        self.camera_manager = get_camera_manager()
        
        # 初始化UI
        self.setup_ui()
        self.load_settings()
        
        # 设置对话框图标
        icon_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            logger.info(f"已加载设置对话框图标: {icon_path}")
        else:
            logger.warning(f"图标文件不存在: {icon_path}")
    
    def setup_ui(self):
        """设置UI"""
        self.setWindowTitle("系统设置")
        self.setMinimumSize(600, 400)
        
        # 主布局
        layout = QVBoxLayout(self)
        
        # 创建选项卡
        self.tab_widget = QTabWidget()
        
        # 常规设置选项卡
        self.general_tab = QWidget()
        self.setup_general_tab()
        self.tab_widget.addTab(self.general_tab, "常规设置")
        
        # 摄像头设置选项卡
        self.camera_tab = QWidget()
        self.setup_camera_tab()
        self.tab_widget.addTab(self.camera_tab, "摄像头设置")
        
        # 检测器设置选项卡
        self.detector_tab = QWidget()
        self.setup_detector_tab()
        self.tab_widget.addTab(self.detector_tab, "检测器设置")
        
        layout.addWidget(self.tab_widget)
        
        # 按钮布局
        button_layout = QHBoxLayout()
        
        self.save_btn = QPushButton("保存")
        self.save_btn.clicked.connect(self.save_settings)
        
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        
        button_layout.addStretch()
        button_layout.addWidget(self.save_btn)
        button_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(button_layout)
    
    def setup_general_tab(self):
        """设置常规选项卡"""
        layout = QVBoxLayout(self.general_tab)
        
        # 系统设置组
        system_group = QGroupBox("系统设置")
        system_layout = QFormLayout(system_group)
        
        # 应用名称
        self.app_name_edit = QLineEdit()
        system_layout.addRow("应用名称:", self.app_name_edit)
        
        # 自动启动
        self.auto_start_check = QCheckBox("程序启动时自动开始检测")
        system_layout.addRow("", self.auto_start_check)
        
        # 日志设置
        self.log_level_combo = QComboBox()
        self.log_level_combo.addItems(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])
        system_layout.addRow("日志级别:", self.log_level_combo)
        
        # 录像设置
        self.save_video_check = QCheckBox("保存报警录像")
        system_layout.addRow("", self.save_video_check)
        
        self.video_length_spin = QSpinBox()
        self.video_length_spin.setRange(5, 60)
        self.video_length_spin.setSuffix(" 秒")
        system_layout.addRow("报警录像长度:", self.video_length_spin)
        
        layout.addWidget(system_group)
        
        # 界面设置组
        ui_group = QGroupBox("界面设置")
        ui_layout = QFormLayout(ui_group)
        
        # 显示FPS
        self.show_fps_check = QCheckBox("显示FPS")
        ui_layout.addRow("", self.show_fps_check)
        
        # 显示检测框
        self.show_boxes_check = QCheckBox("显示检测框")
        ui_layout.addRow("", self.show_boxes_check)
        
        layout.addWidget(ui_group)
        layout.addStretch()
    
    def setup_camera_tab(self):
        """设置摄像头选项卡"""
        layout = QVBoxLayout(self.camera_tab)
        
        # 摄像头列表
        camera_list_group = QGroupBox("摄像头列表")
        camera_list_layout = QVBoxLayout(camera_list_group)
        
        self.camera_table = QTableWidget(0, 4)
        self.camera_table.setHorizontalHeaderLabels(["ID", "名称", "类型", "状态"])
        self.camera_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        camera_list_layout.addWidget(self.camera_table)
        
        # 表格下方的按钮
        table_btn_layout = QHBoxLayout()
        
        self.add_camera_btn = QPushButton("添加摄像头")
        self.add_camera_btn.clicked.connect(self.add_camera)
        
        self.edit_camera_btn = QPushButton("编辑摄像头")
        self.edit_camera_btn.clicked.connect(self.edit_camera)
        
        self.delete_camera_btn = QPushButton("删除摄像头")
        self.delete_camera_btn.clicked.connect(self.delete_camera)
        
        table_btn_layout.addWidget(self.add_camera_btn)
        table_btn_layout.addWidget(self.edit_camera_btn)
        table_btn_layout.addWidget(self.delete_camera_btn)
        table_btn_layout.addStretch()
        
        camera_list_layout.addLayout(table_btn_layout)
        
        layout.addWidget(camera_list_group)
        
        # 默认摄像头设置
        default_camera_group = QGroupBox("默认摄像头设置")
        default_camera_layout = QFormLayout(default_camera_group)
        
        self.default_camera_combo = QComboBox()
        default_camera_layout.addRow("默认摄像头:", self.default_camera_combo)
        
        self.default_resolution_combo = QComboBox()
        self.default_resolution_combo.addItems(["640x480", "1280x720", "1920x1080"])
        default_camera_layout.addRow("默认分辨率:", self.default_resolution_combo)
        
        layout.addWidget(default_camera_group)
        layout.addStretch()
    
    def setup_detector_tab(self):
        """设置检测器选项卡"""
        layout = QVBoxLayout(self.detector_tab)
        
        # 模型设置组
        model_group = QGroupBox("模型设置")
        model_layout = QFormLayout(model_group)
        
        # 模型选择
        self.model_combo = QComboBox()
        self.model_combo.addItems(["YOLOv5s", "YOLOv5m", "YOLOv5l", "YOLOv5x"])
        model_layout.addRow("模型类型:", self.model_combo)
        
        # 模型文件路径
        model_path_layout = QHBoxLayout()
        self.model_path_edit = QLineEdit()
        self.model_path_edit.setReadOnly(True)
        
        self.browse_model_btn = QPushButton("浏览...")
        self.browse_model_btn.clicked.connect(self.browse_model_path)
        
        model_path_layout.addWidget(self.model_path_edit)
        model_path_layout.addWidget(self.browse_model_btn)
        
        model_layout.addRow("模型文件:", model_path_layout)
        
        layout.addWidget(model_group)
        
        # 检测设置组
        detection_group = QGroupBox("检测设置")
        detection_layout = QFormLayout(detection_group)
        
        # 置信度阈值
        self.confidence_spin = QDoubleSpinBox()
        self.confidence_spin.setRange(0.1, 1.0)
        self.confidence_spin.setSingleStep(0.05)
        self.confidence_spin.setDecimals(2)
        detection_layout.addRow("置信度阈值:", self.confidence_spin)
        
        # IoU阈值
        self.iou_spin = QDoubleSpinBox()
        self.iou_spin.setRange(0.1, 1.0)
        self.iou_spin.setSingleStep(0.05)
        self.iou_spin.setDecimals(2)
        detection_layout.addRow("IoU阈值:", self.iou_spin)
        
        # 检测频率
        self.detection_freq_spin = QSpinBox()
        self.detection_freq_spin.setRange(1, 30)
        self.detection_freq_spin.setSuffix(" 帧")
        detection_layout.addRow("检测频率:", self.detection_freq_spin)
        
        layout.addWidget(detection_group)
        
        # 报警设置组
        alarm_group = QGroupBox("报警设置")
        alarm_layout = QFormLayout(alarm_group)
        
        # 报警阈值
        self.alarm_threshold_spin = QDoubleSpinBox()
        self.alarm_threshold_spin.setRange(0.3, 1.0)
        self.alarm_threshold_spin.setSingleStep(0.05)
        self.alarm_threshold_spin.setDecimals(2)
        alarm_layout.addRow("报警阈值:", self.alarm_threshold_spin)
        
        # 连续报警帧数
        self.alarm_frames_spin = QSpinBox()
        self.alarm_frames_spin.setRange(1, 10)
        self.alarm_frames_spin.setSuffix(" 帧")
        alarm_layout.addRow("连续报警帧数:", self.alarm_frames_spin)
        
        # 启用声音报警
        self.enable_sound_check = QCheckBox("启用声音报警")
        alarm_layout.addRow("", self.enable_sound_check)
        
        layout.addWidget(alarm_group)
        layout.addStretch()
    
    def load_settings(self):
        """加载设置"""
        # 获取应用配置
        app_config = self.config.get_config("app")
        ui_config = self.config.get_config("ui")
        detector_config = self.config.get_config("detector")
        alarm_config = self.config.get_config("alarm")
        
        # 常规设置
        self.app_name_edit.setText(app_config.get("app_name", "JENS火灾烟雾报警系统"))
        self.auto_start_check.setChecked(app_config.get("auto_start", False))
        self.log_level_combo.setCurrentText(app_config.get("log_level", "INFO"))
        self.save_video_check.setChecked(app_config.get("save_video", True))
        self.video_length_spin.setValue(app_config.get("video_length", 10))
        
        # 界面设置
        self.show_fps_check.setChecked(ui_config.get("show_fps", True))
        self.show_boxes_check.setChecked(ui_config.get("show_boxes", True))
        
        # 加载摄像头列表
        self.load_camera_list()
        
        # 默认摄像头设置
        self.update_default_camera_combo()
        
        # 检测器设置
        model_name = detector_config.get("model_name", "YOLOv5s")
        self.model_combo.setCurrentText(model_name)
        self.model_path_edit.setText(detector_config.get("model_path", "JENS_models/yolov5s.pt"))
        self.confidence_spin.setValue(detector_config.get("confidence", 0.25))
        self.iou_spin.setValue(detector_config.get("iou", 0.45))
        self.detection_freq_spin.setValue(detector_config.get("detection_freq", 5))
        
        # 报警设置
        self.alarm_threshold_spin.setValue(alarm_config.get("alarm_threshold", 0.6))
        self.alarm_frames_spin.setValue(alarm_config.get("alarm_frames", 3))
        self.enable_sound_check.setChecked(alarm_config.get("enable_sound", True))
    
    def load_camera_list(self):
        """加载摄像头列表"""
        try:
            self.camera_table.setRowCount(0)
            
            cameras = self.camera_manager.get_camera_list()
            
            for i, camera in enumerate(cameras):
                self.camera_table.insertRow(i)
                self.camera_table.setItem(i, 0, QTableWidgetItem(str(camera['id'])))
                self.camera_table.setItem(i, 1, QTableWidgetItem(camera['name']))
                self.camera_table.setItem(i, 2, QTableWidgetItem(camera['type']))
                self.camera_table.setItem(i, 3, QTableWidgetItem("离线"))
        except Exception as e:
            logger.error(f"加载摄像头列表失败: {str(e)}")
    
    def update_default_camera_combo(self):
        """更新默认摄像头下拉列表"""
        self.default_camera_combo.clear()
        
        # 添加默认选项
        self.default_camera_combo.addItem("系统默认摄像头", 0)
        
        # 添加已配置的摄像头
        cameras = self.camera_manager.get_camera_list()
        for camera in cameras:
            self.default_camera_combo.addItem(camera['name'], camera['id'])
        
        # 设置当前选中项
        camera_config = self.config.get_config("camera")
        default_camera_id = camera_config.get("default_camera_id", 0)
        index = self.default_camera_combo.findData(default_camera_id)
        if index >= 0:
            self.default_camera_combo.setCurrentIndex(index)
    
    def save_settings(self):
        """保存设置"""
        # 准备各个模块的配置
        app_config = {}
        ui_config = {}
        camera_config = {}
        detector_config = {}
        alarm_config = {}
        
        # 常规设置
        app_config["app_name"] = self.app_name_edit.text()
        app_config["auto_start"] = self.auto_start_check.isChecked()
        app_config["log_level"] = self.log_level_combo.currentText()
        app_config["save_video"] = self.save_video_check.isChecked()
        app_config["video_length"] = self.video_length_spin.value()
        
        # 界面设置
        ui_config["show_fps"] = self.show_fps_check.isChecked()
        ui_config["show_boxes"] = self.show_boxes_check.isChecked()
        
        # 默认摄像头设置
        camera_config["default_camera_id"] = self.default_camera_combo.currentData()
        
        # 检测器设置
        detector_config["model_name"] = self.model_combo.currentText()
        detector_config["model_path"] = self.model_path_edit.text()
        detector_config["confidence"] = self.confidence_spin.value()
        detector_config["iou"] = self.iou_spin.value()
        detector_config["detection_freq"] = self.detection_freq_spin.value()
        
        # 报警设置
        alarm_config["alarm_threshold"] = self.alarm_threshold_spin.value()
        alarm_config["alarm_frames"] = self.alarm_frames_spin.value()
        alarm_config["enable_sound"] = self.enable_sound_check.isChecked()
        
        # 更新配置
        self.config.set_config("app", app_config)
        self.config.set_config("ui", ui_config)
        self.config.set_config("camera", camera_config)
        self.config.set_config("detector", detector_config)
        self.config.set_config("alarm", alarm_config)
        
        # 保存配置
        try:
            self.config.save_config()
            self.settings_changed.emit()
            self.accept()
            logger.info("已保存设置")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存设置失败：{str(e)}")
            logger.error(f"保存设置失败: {str(e)}")
    
    def add_camera(self):
        """添加摄像头"""
        # 此功能预留给下一阶段实现
        QMessageBox.information(self, "提示", "该功能将在下一阶段实现")
    
    def edit_camera(self):
        """编辑摄像头"""
        # 此功能预留给下一阶段实现
        QMessageBox.information(self, "提示", "该功能将在下一阶段实现")
    
    def delete_camera(self):
        """删除摄像头"""
        # 此功能预留给下一阶段实现
        QMessageBox.information(self, "提示", "该功能将在下一阶段实现")
    
    def browse_model_path(self):
        """浏览模型文件路径"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择模型文件", "", 
            "PyTorch模型 (*.pt);;ONNX模型 (*.onnx);;所有文件 (*.*)"
        )
        
        if file_path:
            self.model_path_edit.setText(file_path)
