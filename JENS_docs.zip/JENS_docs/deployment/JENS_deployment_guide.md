# JENS火灾烟雾报警系统部署指南

## 1. 系统要求

### 1.1 硬件要求
- **处理器**：Intel i5 8代或更高/AMD Ryzen 5 或更高
- **内存**：至少8GB RAM，推荐16GB
- **存储**：至少20GB可用空间，推荐SSD存储
- **显卡**：
  - 基础模式：集成显卡
  - 高性能模式：NVIDIA GTX 1050或更高级别GPU，支持CUDA
- **摄像头**：
  - USB摄像头（至少720p分辨率）
  - 或IP摄像头（支持RTSP协议）
  - 或ONVIF协议摄像头
- **显示器**：1080p或更高分辨率
- **音频设备**：用于播放报警声音
- **网络**：有线或无线网络连接，建议千兆网络（如使用多个IP摄像头）

### 1.2 软件要求
- **操作系统**：
  - Windows 10/11（64位）
  - 或 Ubuntu 18.04+/CentOS 7+（64位）
- **Python**：3.8或更高版本
- **CUDA**：10.2或更高版本（仅GPU模式需要）
- **cuDNN**：与CUDA版本匹配的版本（仅GPU模式需要）
- **MySQL**：5.7或8.0版本
- **其他依赖**：见requirements.txt

## 2. 安装步骤

### 2.1 安装Python环境

#### Windows环境
1. 从[Python官网](https://www.python.org/downloads/)下载并安装Python 3.8或更高版本
2. 安装时勾选"Add Python to PATH"选项
3. 建议勾选"Install pip"以便安装依赖包
4. 验证安装：打开命令提示符或PowerShell，输入:
   ```
   python --version
   pip --version
   ```

#### Linux环境
1. 更新系统包并安装必要工具:
   ```bash
   sudo apt update && sudo apt upgrade -y  # Ubuntu/Debian
   # 或
   sudo yum update -y  # CentOS/RHEL
   ```

2. 安装Python 3.8或更高版本:
   ```bash
   # Ubuntu/Debian
   sudo apt install -y python3 python3-pip python3-dev
   
   # CentOS/RHEL
   sudo yum install -y python38 python38-pip python38-devel
   ```

3. 验证安装:
   ```bash
   python3 --version
   pip3 --version
   ```

### 2.2 安装MySQL数据库

#### Windows环境
1. 从[MySQL官网](https://dev.mysql.com/downloads/installer/)下载MySQL安装程序
2. 运行安装程序，选择"Server only"选项或自定义安装
3. 设置root密码，记录此密码以便后续使用
4. 完成安装后，确认MySQL服务已启动

#### Linux环境
1. 安装MySQL:
   ```bash
   # Ubuntu/Debian
   sudo apt install -y mysql-server
   
   # CentOS/RHEL
   sudo yum install -y mysql-server
   sudo systemctl start mysqld
   sudo systemctl enable mysqld
   ```

2. 设置root密码和基本安全选项:
   ```bash
   sudo mysql_secure_installation
   ```

3. 验证MySQL服务状态:
   ```bash
   sudo systemctl status mysql  # Ubuntu/Debian
   sudo systemctl status mysqld  # CentOS/RHEL
   ```

### 2.3 下载项目代码
1. 安装Git（如未安装）:
   ```bash
   # Windows: 从https://git-scm.com/download/win下载安装
   
   # Ubuntu/Debian
   sudo apt install -y git
   
   # CentOS/RHEL
   sudo yum install -y git
   ```

2. 通过Git克隆项目：
   ```bash
   git clone https://github.com/jenkenssq/JENS_FireSmoke_Detection.git
   ```
   或下载项目ZIP包并解压

3. 进入项目目录：
   ```bash
   cd JENS_FireSmoke_Detection
   ```

### 2.4 安装依赖库
1. 创建虚拟环境（可选但推荐）:
   ```bash
   # Windows
   python -m venv venv
   venv\Scripts\activate
   
   # Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

2. 使用pip安装所需依赖：
   ```bash
   pip install -r requirements.txt
   ```

3. 对于GPU加速（可选），安装CUDA和cuDNN：
   - 从[NVIDIA官网](https://developer.nvidia.com/cuda-downloads)下载并安装适合您系统的CUDA
   - 从[NVIDIA官网](https://developer.nvidia.com/cudnn)下载并安装cuDNN
   - 确保环境变量正确设置:
     ```bash
     # Windows: 添加到系统环境变量PATH
     # Linux: 添加到~/.bashrc或/etc/environment
     ```

### 2.5 下载模型文件
1. 运行模型下载脚本：
   ```bash
   python JENS_download_models.py
   # 或在Linux上
   python3 JENS_download_models.py
   ```

2. 按照菜单提示下载所需模型：
   - YOLOv5s（推荐，平衡速度和准确性）
   - YOLOv5n（轻量级，适合低配置系统）
   - 专用火灾烟雾检测模型（最佳检测效果）

### 2.6 配置数据库
1. 创建数据库和用户：

   #### 方法一：使用命令行
   ```bash
   # 登录MySQL
   mysql -u root -p
   
   # 在MySQL提示符下执行
   CREATE DATABASE jens_fire_smoke DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'jens_user'@'localhost' IDENTIFIED BY 'your_password';
   GRANT ALL PRIVILEGES ON jens_fire_smoke.* TO 'jens_user'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   
   # 导入数据库结构
   mysql -u jens_user -p jens_fire_smoke < JENS_utils/init_database.sql
   ```

   #### 方法二：使用初始化脚本
   ```bash
   # 登录MySQL
   mysql -u root -p
   
   # 运行初始化脚本
   source JENS_utils/init_database.sql
   ```

   #### 方法三：使用图形化工具(如MySQL Workbench)
   1. 打开MySQL Workbench并连接到您的MySQL服务器
   2. 创建一个新的查询标签
   3. 将`JENS_utils/init_database.sql`文件内容复制到查询窗口
   4. 执行脚本

2. 验证数据库创建：
   ```bash
   mysql -u jens_user -p -e "USE jens_fire_smoke; SHOW TABLES;"
   ```
   应显示创建的表列表，包括`jens_devices`、`jens_alarms`等

### 2.7 系统配置
1. 首次运行系统生成配置文件：
   ```bash
   # Windows
   python JENS_main.py --init-config
   
   # Linux
   python3 JENS_main.py --init-config
   ```

2. 编辑配置文件`config.json`：
   - 设置数据库连接信息
   - 修改摄像头设置
   - 调整检测参数
   - 配置报警策略
   - 设置存储路径

3. 数据库连接配置示例：
   ```json
   {
     "database": {
       "host": "localhost",
       "port": 3306,
       "user": "jens_user",
       "password": "your_password",
       "database": "jens_fire_smoke",
       "charset": "utf8mb4"
     }
   }
   ```

## 3. 运行系统

### 3.1 启动系统
1. 运行主程序：
   ```bash
   # Windows
   python JENS_main.py
   
   # Linux
   python3 JENS_main.py
   ```

2. 添加启动参数（可选）：
   - 使用配置文件：`python JENS_main.py --config custom_config.json`
   - 无界面模式：`python JENS_main.py --no-gui`
   - 调试模式：`python JENS_main.py --debug`
   - 仅使用CPU：`python JENS_main.py --cpu-only`

### 3.2 Linux环境下无界面运行
1. 安装必要的X服务器包：
   ```bash
   # Ubuntu/Debian
   sudo apt install -y xvfb
   
   # CentOS/RHEL
   sudo yum install -y xorg-x11-server-Xvfb
   ```

2. 使用xvfb-run启动程序：
   ```bash
   xvfb-run python3 JENS_main.py --no-gui
   ```

3. 设置为系统服务（可选）：
   ```bash
   # 创建服务文件
   sudo nano /etc/systemd/system/jens.service
   ```
   
   添加以下内容：
   ```
   [Unit]
   Description=JENS Fire Smoke Detection System
   After=network.target mysql.service
   
   [Service]
   Type=simple
   User=your_username
   WorkingDirectory=/path/to/JENS_FireSmoke_Detection
   ExecStart=/usr/bin/xvfb-run /usr/bin/python3 JENS_main.py --no-gui
   Restart=on-failure
   
   [Install]
   WantedBy=multi-user.target
   ```
   
   启用服务：
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable jens.service
   sudo systemctl start jens.service
   ```

### 3.3 Windows环境下设置开机自启
1. 创建批处理文件（如`start_jens.bat`）：
   ```bat
   @echo off
   cd /d D:\path\to\JENS_FireSmoke_Detection
   python JENS_main.py
   ```

2. 将批处理文件快捷方式放入启动文件夹：
   - 按下`Win + R`，输入`shell:startup`打开启动文件夹
   - 将批处理文件的快捷方式复制到此文件夹

### 3.4 验证系统运行
1. 检查系统主界面是否正常显示
2. 测试摄像头连接
3. 验证检测功能
4. 测试报警功能
5. 查看日志文件确认系统正常运行：
   ```bash
   # Windows
   type logs\JENS_main.log
   
   # Linux
   cat logs/JENS_main.log
   ```

## 4. 系统配置详解

### 4.1 摄像头配置
```json
{
  "cameras": {
    "default_camera": 0,
    "camera_list": [
      {"id": 0, "name": "内置摄像头", "type": "usb", "source": 0},
      {"id": 1, "name": "IP摄像头", "type": "rtsp", "source": "rtsp://admin:password@192.168.1.64:554/h264"},
      {"id": 2, "name": "ONVIF摄像头", "type": "onvif", "source": "192.168.1.65", "port": 80, "username": "admin", "password": "admin123"}
    ],
    "frame_rate": 15,
    "resolution": [640, 480],
    "rotate": 0,
    "reconnect_attempts": 3,
    "reconnect_delay": 5
  }
}
```

### 4.2 检测器配置
```json
{
  "detector": {
    "model": "yolov5s.pt",
    "confidence_threshold": 0.4,
    "iou_threshold": 0.45,
    "device": "auto",
    "img_size": 640,
    "max_det": 1000,
    "classes": [0, 1],  # 0: fire, 1: smoke
    "detection_frequency": 5  # 每秒检测帧数
  }
}
```

### 4.3 报警配置
```json
{
  "alarm": {
    "alarm_threshold": 0.6,
    "warning_threshold": 0.4,
    "alarm_frames": 3,
    "enable_sound": true,
    "sound_file": "JENS_assets/sounds/alarm.mp3",
    "save_alarm_images": true,
    "save_alarm_videos": true,
    "video_before_alarm": 10,  # 报警前保存的视频秒数
    "video_after_alarm": 30,   # 报警后保存的视频秒数
    "notification_enabled": true,
    "email_notification": {
      "enabled": false,
      "smtp_server": "smtp.example.com",
      "smtp_port": 587,
      "smtp_user": "alarm@example.com",
      "smtp_password": "your_password",
      "recipients": ["admin@example.com"]
    }
  }
}
```

### 4.4 存储配置
```json
{
  "storage": {
    "base_dir": "JENS_storage",
    "images_dir": "JENS_storage/images",
    "videos_dir": "JENS_storage/videos",
    "max_days": 30,
    "max_space_gb": 50,
    "cleanup_policy": "oldest_first",
    "compress_old_files": true
  }
}
```

### 4.5 系统配置
```json
{
  "system": {
    "log_level": "INFO",
    "language": "zh_CN",
    "theme": "dark",
    "auto_start": true,
    "minimize_to_tray": true,
    "check_update": true,
    "update_url": "https://api.github.com/repos/jenkenssq/JENS_FireSmoke_Detection/releases/latest"
  }
}
```

## 5. 系统维护

### 5.1 日志管理
- 日志文件位于`logs`目录
- 定期检查日志文件，排查潜在问题
- 定期清理旧日志文件：
  ```bash
  # Windows
  python JENS_clean_logs.py --days 30
  
  # Linux
  python3 JENS_clean_logs.py --days 30
  ```

### 5.2 数据库维护

#### 备份数据库
```bash
# Windows
python JENS_backup_database.py --output backup/jens_db_backup.sql

# Linux
python3 JENS_backup_database.py --output backup/jens_db_backup.sql

# 或直接使用MySQL工具
mysqldump -u jens_user -p jens_fire_smoke > backup/jens_db_backup.sql
```

#### 恢复数据库
```bash
# 从备份恢复
mysql -u jens_user -p jens_fire_smoke < backup/jens_db_backup.sql
```

#### 清理旧记录
```bash
# 清理90天前的报警记录
python3 JENS_clean_alarms.py --days 90
```

#### MySQL性能优化
1. 确保为`jens_alarms`表的`alarm_time`列创建索引
2. 定期优化数据库表：
   ```sql
   OPTIMIZE TABLE jens_alarms, jens_devices, jens_alarm_stats;
   ```

### 5.3 存储空间管理
1. 定期检查存储空间使用情况：
   ```bash
   # Windows
   python JENS_check_storage.py
   
   # Linux
   python3 JENS_check_storage.py
   ```

2. 手动清理旧文件：
   ```bash
   # 清理30天前的报警图像和视频
   python3 JENS_clean_files.py --days 30 --type all
   ```

3. 定期维护存储设备

### 5.4 系统更新
1. 检查更新：
   ```bash
   # Windows
   python JENS_check_update.py
   
   # Linux
   python3 JENS_check_update.py
   ```

2. 拉取最新代码：
   ```bash
   git pull origin main
   ```

3. 更新依赖：
   ```bash
   pip install -r requirements.txt --upgrade
   ```

4. 更新数据库结构（如果需要）：
   ```bash
   mysql -u jens_user -p jens_fire_smoke < JENS_utils/update_database.sql
   ```

## 6. 故障排除

### 6.1 常见问题

#### 无法连接摄像头
- 检查摄像头是否正确连接
- 验证摄像头驱动是否安装
- 确认摄像头设备ID是否正确
- 对于IP摄像头，检查网络连接和认证信息
- 使用第三方工具（如VLC）验证摄像头是否可访问

#### 检测器不工作
- 确认模型文件存在于`JENS_models`目录
- 检查GPU驱动和CUDA安装（如使用GPU加速）
- 查看日志文件确认具体错误
- 尝试使用CPU模式运行：`python JENS_main.py --cpu-only`

#### 数据库连接错误
- 确认MySQL服务是否运行
- 检查数据库连接配置
- 验证用户权限
- MySQL服务器防火墙设置是否允许连接

#### PySide6界面问题
- 确保已安装PySide6及其依赖
- 在Linux环境下，确保已安装必要的X11库：
  ```bash
  # Ubuntu/Debian
  sudo apt install -y libxcb-xinerama0 libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-randr0 libxcb-render-util0 libxcb-xkb1 libxkbcommon-x11-0
  ```

#### 系统性能问题
- 降低摄像头分辨率
- 使用更轻量级的模型（如yolov5n）
- 减少检测频率
- 减少同时处理的摄像头数量
- 使用更强劲的硬件（特别是GPU）

### 6.2 日志分析
查看日志文件以获取详细错误信息：
```bash
# Windows
type logs\JENS_main.log
type logs\JENS_detector.log
type logs\JENS_camera.log

# Linux
cat logs/JENS_main.log
cat logs/JENS_detector.log
cat logs/JENS_camera.log

# 实时查看日志
tail -f logs/JENS_main.log
```

### 6.3 诊断工具
使用系统自带的诊断工具：
```bash
python JENS_diagnostics.py
```

诊断工具会检查：
- 系统环境配置
- 依赖库安装状态
- 模型文件完整性
- 数据库连接状态
- 摄像头可访问性
- GPU状态和CUDA配置

### 6.4 联系支持
遇到无法解决的问题，请联系系统支持团队：
- 邮箱：support@jens-system.com
- 电话：400-123-4567
- 在线支持：https://www.jens-system.com/support

## 7. 安全建议

### 7.1 系统安全
- 定期更新系统和依赖库
- 使用强密码保护数据库
- 限制系统访问权限
- 启用系统防火墙
- 定期安装操作系统安全补丁

### 7.2 网络安全
- 将系统部署在受保护的内网环境
- 使用防火墙限制访问
- 对IP摄像头使用加密连接
- 考虑为摄像头设置独立的网络分段
- 使用VPN访问远程摄像头

### 7.3 数据安全
- 定期备份报警数据和数据库
- 加密敏感配置信息
- 定期清理不需要的报警图像和视频
- 设置适当的数据保留策略
- 对存储介质进行加密（如有高安全需求）

### 7.4 物理安全
- 将系统主机放置在安全区域
- 限制对系统硬件的物理访问
- 确保服务器有稳定的电源供应
- 考虑使用不间断电源(UPS)保障系统可靠性 
- 定期清理不需要的报警图像和视频 